if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si3658:{
name:'Character_Block_1',
type:1268,
from:14584,
to:14673,
rp:0,
rpa:0,
mdi:'si3658c',
tag:'character-block-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":360,"autoFit":true,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"24px","padding":"8% 4% 8% 1%"},"tablet":{"display":"flex","flexDirection":"column","padding":"5%"},"mobile":{"display":"flex","flexDirection":"column","gap":"24px","padding":"5%"}},"appearanceProperties":{}}',
retainState:false,
immo:false,
apsn:'Slide3417',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3666',
t:1268
}
,{
n:'si3688',
t:1268
}
]
,
containerType:'character-block',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":360,"autoFit":true,"alignment":{"character-container-1":"LEFT","isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"24px","padding":"8% 4% 8% 1%"},"tablet":{"display":"flex","flexDirection":"column","padding":"5%"},"mobile":{"display":"flex","flexDirection":"column","gap":"24px","padding":"5%"}},"appearanceProperties":{}}',
option:'SINGLE_CHARACTER_OPTION_1',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3658c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3658,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3658',
visible:1,
effectiveVi:1,
JSONEffectData:false,
gf:{
b:[0,0,0,0],
t:3,
x1:0,
y1:0,
x2:100,
y2:100,
s:0,
cs:[{
p:0,
c:'#cdd1de',
o:255
}
,{
p:100,
c:'#5fbb97',
o:255
}
]

}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3666:{
name:'character-image_1',
type:1268,
from:7786,
to:7875,
rp:0,
rpa:0,
mdi:'si3666c',
tag:'character-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"flex":"none","alignSelf":"center","padding":"40px 20px 40px 20px","maxWidth":"50%"},"tablet":{},"mobile":{}}}',
parentGroup:'si3658',
retainState:false,
immo:false,
apsn:'Slide3417',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3676',
t:15
}
]
,
containerType:'character-container-1',
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"flex":"none","alignSelf":"center","padding":"40px 20px 40px 20px","maxWidth":"50%"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3658',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3666c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3666,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3666',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3676:{
name:'IMG_9527_1',
type:15,
from:7786,
to:7875,
rp:0,
rpa:0,
mdi:'si3676c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3666',
retainState:false,
immo:false,
apsn:'Slide3417',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:2417,
irh:3600,
w:2417,
h:3600,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3676]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3676c:{
b:[0,0,2417,3600],
fh:false,
fw:false,
uid:3676,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03655.jpg',
dn:'si3676',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,2418,3601],
vb:[-1,-1,2418,3601]
},
si3688:{
name:'Character_Group_1',
type:1268,
from:14584,
to:14673,
rp:0,
rpa:0,
mdi:'si3688c',
tag:'character-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":60,"bottom":60,"left":60,"right":60},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"#5FBB97","size":6,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{"padding":"40px"},"mobile":{"marginTop":"0%","padding":"20px"}}}',
parentGroup:'si3658',
retainState:false,
immo:false,
apsn:'Slide3417',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3696',
t:1250
}
,{
n:'si3706',
t:1250
}
]
,
containerType:'character-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":60,"bottom":60,"left":60,"right":60},"alignment":{"slide-item-button":"LEFT","slide-item-heading":"LEFT","slide-item-body":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"#5FBB97","size":6,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center"},"tablet":{"padding":"40px"},"mobile":{"marginTop":"0%","padding":"20px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3658',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3688c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3688,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3688',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c3)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3696:{
name:'Text_3',
type:1250,
from:7786,
to:7875,
rp:0,
rpa:0,
mdi:'si3696c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"marginBottom":"18px"},"tablet":{},"mobile":{}}}',
parentGroup:'si3688',
retainState:false,
immo:false,
apsn:'Slide3417',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f9l39","text":"Creating an Instagram post using Canva","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"overridden:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-heading-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3696]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3696c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3696,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3696',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3706:{
name:'Text_4',
type:1250,
from:14584,
to:14673,
rp:0,
rpa:0,
mdi:'si3706c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3688',
retainState:false,
immo:false,
apsn:'Slide3417',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fu6fe","text":"My name is Michele Nizza. In today\'s training, I will teach you how to create an Instagram post using Canva, an online graphic design application. Please click on the arrow below to begin. ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":189,"style":"hlnk:"},{"offset":0,"length":189,"style":"hlnkt:wp"},{"offset":0,"length":189,"style":"textOutlineEnable:false"},{"offset":0,"length":189,"style":"opacity:1"},{"offset":0,"length":189,"style":"hlnke:true"},{"offset":0,"length":189,"style":"backgroundColor:unset"},{"offset":0,"length":189,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":189,"style":"textHighlightEnable:false"},{"offset":0,"length":189,"style":"textShadowEnable:false"},{"offset":0,"length":189,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3706]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3706c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3706,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3706',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
Slide3417:{
lb:'Blank 1',
id:3417,
from:14584,
to:14673,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3417c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si3658',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide3417c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3417,
dn:'Slide3417',
visible:'1'
},
StAd25:{
from:14674,
to:15057,
src:'ar/StAd24.mp3',
du:12800,
saup:[{
sn:390,
del:0,
du:12.8,
l:false
}
]

},
si416:{
name:'Simulation_1',
type:1268,
from:7876,
to:8283,
rp:0,
rpa:0,
mdi:'si416c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si408',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si416c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:416,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si416',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si408:{
name:'Simulation_non_responsive_1',
type:1268,
from:7876,
to:8283,
rp:0,
rpa:0,
mdi:'si408c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si416',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si427',
t:1269
}
,{
n:'si447',
t:612
}
,{
n:'si3064',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si416',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si408c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:408,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si408',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:424,
tsp:50,
ip:'dr/0424.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si427:{
name:'Click_box_1',
type:1269,
from:1,
to:408,
rp:0,
rpa:0,
mdi:'si427c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":52,"left":158,"width":889,"height":24},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(500);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:13.59,
lcapid:'si447',
si:[{
n:'si437',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[427]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si427c:{
b:[158,52,1047,76],
fh:false,
fw:false,
uid:427,
iso:false,
css:{
360:{
l:'16.255%',
t:'8.553%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'16.255%',
lhID:-1,
lvEID:0,
lvV:'8.553%',
lvID:-1,
w:'91.461%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'16.255%',
t:'8.553%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'16.255%',
lhID:-1,
lvEID:0,
lvV:'8.553%',
lvID:-1,
w:'91.461%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'16.255%',
t:'8.553%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'16.255%',
lhID:-1,
lvEID:0,
lvV:'8.553%',
lvID:-1,
w:'91.461%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si427',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[158,52,1047,76],
vb:[158,52,1047,76]
},
si437:{
name:'Shape_1',
type:612,
from:1,
to:408,
rp:0,
rpa:0,
mdi:'si437c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[437]
}
]
,
stis:0,
bstiid:427,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si427',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si437c:{
b:[0,0,889,24],
fh:false,
fw:false,
uid:437,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'91.461%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'91.461%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'91.461%',
h:'3.947%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si437',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,891,26],
vb:[-2,-2,891,26]
},
si447:{
name:'Rectangle_1',
type:612,
from:7876,
to:8283,
rp:0,
rpa:0,
mdi:'si447c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":112,"left":173,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:458,
stt:0,
dsr:'Default_State',
stsi:[447]
}
,{
stn:481,
stt:103,
dsr:'Hint',
stsi:[482]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si447','si460','si471','si482'],
isDD:false
},
si447c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:447,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si447',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si460:{
name:'',
type:612,
from:1,
to:408,
rp:0,
rpa:0,
mdi:'si460c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":112,"left":173,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si447',
stl:[{
stn:'Normal',
stt:0,
stsi:[460]
}
]
,
stis:0,
bstiid:447,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:447,
isDD:false
},
si460c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:460,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si460',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si471:{
name:'',
type:612,
from:1,
to:408,
rp:0,
rpa:0,
mdi:'si471c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":112,"left":173,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si447',
stl:[{
stn:'Normal',
stt:0,
stsi:[471]
}
]
,
stis:0,
bstiid:447,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:447,
isDD:false
},
si471c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:471,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si471',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si482:{
name:'',
type:612,
from:1,
to:408,
rp:0,
rpa:0,
mdi:'si482c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":112,"left":173,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si447',
stl:[{
stn:'Normal',
stt:0,
stsi:[482]
}
]
,
stis:0,
bstiid:447,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:447,
isDD:false
},
si482c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:482,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si482',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3064:{
name:'Instructions_1',
type:612,
from:1,
to:408,
rp:0,
rpa:0,
mdi:'si3064c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Type canva.com in the address box","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":33,"style":"hlnkt:wp"},{"offset":0,"length":33,"style":"textOutlineEnable:false"},{"offset":0,"length":33,"style":"opacity:1"},{"offset":0,"length":33,"style":"textShadowColor:ffffff00"},{"offset":0,"length":33,"style":"hlnke:true"},{"offset":0,"length":33,"style":"backgroundColor:unset"},{"offset":0,"length":33,"style":"textShadowX:0px"},{"offset":0,"length":33,"style":"textShadowY:0px"},{"offset":0,"length":33,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":33,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":33,"style":"textShadowBlur:0px"},{"offset":0,"length":33,"style":"textHighlightEnable:false"},{"offset":0,"length":33,"style":"textShadowEnable:false"},{"offset":0,"length":33,"style":"hlnk:"},{"offset":0,"length":33,"style":"overridden:false"},{"offset":0,"length":33,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":545.292817679558,"top":142.76243093922653,"width":343.4806528671011},"shouldRender":true}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3064]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3064c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3064,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3064',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide390:{
lb:'Simulation slide 1',
id:390,
from:7876,
to:8283,
iols:0,
i360qs:false,
sdu:13.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide390c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si416',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
500:{
ts:''
}

}

},
Slide390c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:390,
dn:'Slide390',
visible:'1'
},
StAd27:{
from:14674,
to:14718,
src:'ar/StAd26.mp3',
du:1500,
saup:[{
sn:507,
del:0,
du:1.5,
l:false
}
]

},
si533:{
name:'Simulation_2',
type:1268,
from:8284,
to:8346,
rp:0,
rpa:0,
mdi:'si533c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si525',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si533c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:533,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si533',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si525:{
name:'Simulation_non_responsive_2',
type:1268,
from:8284,
to:8346,
rp:0,
rpa:0,
mdi:'si525c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-inputfield":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-inputfield":1},"canBeCard":false}',
parentGroup:'si533',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si544',
t:2433
}
,{
n:'si574',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-inputfield":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-inputfield":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si533',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si525c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:525,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si525',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:541,
tsp:50,
ip:'dr/0541.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si544:{
name:'InputField_1',
type:2433,
from:409,
to:471,
rp:0,
rpa:0,
mdi:'si544c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[572,573],
siaf:0,
sid:2.1,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":true,"error":true},"scaleValue":"medium","currentState":"normal","isTextActive":true,"inputFieldProps":{"answersList":["canva.com"],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"3u77k","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"active":{"opacity":100,"editorState":{"blocks":[{"key":"t7ru","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"s16q","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"1b65o","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"error":{"opacity":100,"editorState":{"blocks":[{"key":"cducb","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"8"}},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"sizeNPos":{"top":51,"left":115,"width":1118,"height":23},"attempts":1024}',
parentGroup:'si525',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
ofov:'{"scripts":[{"then":[["cp.jumpToNextSlide(621);"]]}]}',
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:['canva.com'],
si:[]
,
te:true,
ie:false,
lcapid:'si574',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[544]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si544c:{
b:[115,51,1233,74],
fh:false,
fw:false,
uid:544,
iso:false,
css:{
360:{
l:'11.831%',
t:'8.388%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'11.831%',
lhID:-1,
lvEID:0,
lvV:'8.388%',
lvID:-1,
w:'115.021%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'11.831%',
t:'8.388%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'11.831%',
lhID:-1,
lvEID:0,
lvV:'8.388%',
lvID:-1,
w:'115.021%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'11.831%',
t:'8.388%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'11.831%',
lhID:-1,
lvEID:0,
lvV:'8.388%',
lvID:-1,
w:'115.021%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si544',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[115,51,1233,74],
vb:[115,51,1233,74]
},
si574:{
name:'Rectangle_2',
type:612,
from:8284,
to:8346,
rp:0,
rpa:0,
mdi:'si574c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":111,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si525',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si574','si587','si598','si609'],
isDD:false
},
si574c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:574,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si574',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si587:{
name:'',
type:612,
from:409,
to:471,
rp:0,
rpa:0,
mdi:'si587c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":111,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si525',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si574',
stl:[{
stn:'Normal',
stt:0,
stsi:[587]
}
]
,
stis:0,
bstiid:574,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:574,
isDD:false
},
si587c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:587,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si587',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si598:{
name:'',
type:612,
from:409,
to:471,
rp:0,
rpa:0,
mdi:'si598c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":111,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si525',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si574',
stl:[{
stn:'Normal',
stt:0,
stsi:[598]
}
]
,
stis:0,
bstiid:574,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:574,
isDD:false
},
si598c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:598,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si598',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si609:{
name:'',
type:612,
from:409,
to:471,
rp:0,
rpa:0,
mdi:'si609c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":111,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si525',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si574',
stl:[{
stn:'Normal',
stt:0,
stsi:[609]
}
]
,
stis:0,
bstiid:574,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:574,
isDD:false
},
si609c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:609,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si609',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide507:{
lb:'Simulation slide 2',
id:507,
from:8284,
to:8346,
iols:0,
i360qs:false,
sdu:2.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide507c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si533',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
621:{
ts:''
}

}

},
Slide507c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:507,
dn:'Slide507',
visible:'1'
},
si648:{
name:'Simulation_3',
type:1268,
from:8347,
to:9000,
rp:0,
rpa:0,
mdi:'si648c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si640',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si648c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:648,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si648',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si640:{
name:'Simulation_non_responsive_3',
type:1268,
from:8347,
to:9000,
rp:0,
rpa:0,
mdi:'si640c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si648',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3074',
t:612
}
,{
n:'si3084',
t:12
}
,{
n:'si3120',
t:612
}
,{
n:'si3100',
t:1269
}
,{
n:'si3200',
t:612
}
,{
n:'si3180',
t:1269
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si648',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si640c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:640,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si640',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:656,
tsp:50,
ip:'dr/0656.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3074:{
name:'Instructions_2',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3074c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Click on Instagram Post (Square)","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":32,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":32,"style":"hlnkt:wp"},{"offset":0,"length":32,"style":"textOutlineEnable:false"},{"offset":0,"length":32,"style":"opacity:1"},{"offset":0,"length":32,"style":"textShadowColor:ffffff00"},{"offset":0,"length":32,"style":"hlnke:true"},{"offset":0,"length":32,"style":"backgroundColor:unset"},{"offset":0,"length":32,"style":"textShadowX:0px"},{"offset":0,"length":32,"style":"textShadowY:0px"},{"offset":0,"length":32,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":32,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":32,"style":"textShadowBlur:0px"},{"offset":0,"length":32,"style":"textHighlightEnable:false"},{"offset":0,"length":32,"style":"textShadowEnable:false"},{"offset":0,"length":32,"style":"hlnk:"},{"offset":0,"length":32,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":399.6850828729282,"top":475.29281767955797,"width":325.5248517621288},"shouldRender":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3074]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3074c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3074,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3074',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3084:{
name:'Mouse_1',
type:12,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3084c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":0,"mouseStartPointY":0,"mouseEndPointX":16,"mouseEndPointY":16}}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si3084Ad',
trin:0,
trout:0,
isDD:false
},
si3084c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3084,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3084',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si3084Ad:{
src:'ar/Mouse.mp3',
from:472,
to:477,
del:21.618,
msa:1,
du:0.182
},
si3120:{
name:'Rectangle_20',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3120c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3131,
stt:0,
dsr:'Default_State',
stsi:[3120]
}
,{
stn:3143,
stt:102,
dsr:'Failure',
stsi:[3144]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3120','si3133','si3144','si3155'],
isDD:false
},
si3120c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3120,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3120',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3133:{
name:'',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3133c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3120',
stl:[{
stn:'Normal',
stt:0,
stsi:[3133]
}
]
,
stis:0,
bstiid:3120,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3120,
isDD:false
},
si3133c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3133,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3133',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3144:{
name:'',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3144c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3120',
stl:[{
stn:'Normal',
stt:0,
stsi:[3144]
}
]
,
stis:0,
bstiid:3120,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3120,
isDD:false
},
si3144c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3144,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3144',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3155:{
name:'',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3155c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"}}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3120',
stl:[{
stn:'Normal',
stt:0,
stsi:[3155]
}
]
,
stis:0,
bstiid:3120,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3120,
isDD:false
},
si3155c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3155,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3155',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3100:{
name:'Highlight_box_1',
type:1269,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3100c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1132,"top":24,"width":128,"height":32},"shouldRender":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si3110',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3100]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3100c:{
b:[1132,24,1260,56],
fh:false,
fw:false,
uid:3100,
iso:false,
css:{
360:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'116.461%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.461%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3100',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1132,24,1260,56],
vb:[1132,24,1260,56]
},
si3110:{
name:'Shape_16',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3110c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3110]
}
]
,
stis:0,
bstiid:3100,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si3100',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si3110c:{
b:[0,0,128,32],
fh:false,
fw:false,
uid:3110,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'13.169%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3110',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,130,34],
vb:[-2,-2,130,34]
},
si3200:{
name:'Rectangle_21',
type:612,
from:8347,
to:9000,
rp:0,
rpa:0,
mdi:'si3200c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3211,
stt:0,
dsr:'Default_State',
stsi:[3200]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3200','si3213','si3224','si3235'],
isDD:false
},
si3200c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3200,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3200',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3213:{
name:'',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3213c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3200',
stl:[{
stn:'Normal',
stt:0,
stsi:[3213]
}
]
,
stis:0,
bstiid:3200,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3200,
isDD:false
},
si3213c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3213,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3213',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3224:{
name:'',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3224c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3200',
stl:[{
stn:'Normal',
stt:0,
stsi:[3224]
}
]
,
stis:0,
bstiid:3200,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3200,
isDD:false
},
si3224c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3224,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3224',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3235:{
name:'',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3235c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":14,"width":300,"height":"auto"},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3200',
stl:[{
stn:'Normal',
stt:0,
stsi:[3235]
}
]
,
stis:0,
bstiid:3200,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3200,
isDD:false
},
si3235c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:3235,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3235',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3180:{
name:'Click_box_16',
type:1269,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3180c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":455.56353591160234,"top":528.1436464088397,"width":211.7801898092196,"height":185.54691715135095},"shouldRender":true,"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si640',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(3253);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1,
pa:-1,
lcapid:'si3200',
si:[{
n:'si3190',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3180]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3180c:{
b:[1352,24,1416,88],
fh:false,
fw:false,
uid:3180,
iso:false,
css:{
360:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'139.095%',
t:'3.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'139.095%',
lhID:-1,
lvEID:0,
lvV:'3.947%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3180',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1352,24,1416,88],
vb:[1352,24,1416,88]
},
si3190:{
name:'Shape_17',
type:612,
from:472,
to:1125,
rp:0,
rpa:0,
mdi:'si3190c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:21.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide622',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3190]
}
]
,
stis:0,
bstiid:3180,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si3180',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si3190c:{
b:[0,0,64,64],
fh:false,
fw:false,
uid:3190,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'10.526%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3190',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,66],
vb:[-2,-2,66,66]
},
Slide622:{
lb:'Simulation slide 3',
id:622,
from:8347,
to:9000,
iols:0,
i360qs:false,
sdu:21.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide622c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si648',
t:1268
}
]
,
iph:[]
,
oa:'si3084Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
3253:{
ts:''
}

}

},
Slide622c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:622,
dn:'Slide622',
visible:'1'
},
si765:{
name:'Simulation_4',
type:1268,
from:9001,
to:9681,
rp:0,
rpa:0,
mdi:'si765c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si757',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si765c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:765,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si765',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si757:{
name:'Simulation_non_responsive_4',
type:1268,
from:9001,
to:9681,
rp:0,
rpa:0,
mdi:'si757c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si765',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si776',
t:1269
}
,{
n:'si796',
t:612
}
,{
n:'si3260',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si765',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si757c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:757,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si757',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:773,
tsp:50,
ip:'dr/0773.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si776:{
name:'Click_box_3',
type:1269,
from:1126,
to:1806,
rp:0,
rpa:0,
mdi:'si776c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":457.3756906077348,"left":120.1878453038674,"width":108.56206904458735,"height":50.36863042504747},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(849);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:22.685,
lcapid:'si796',
si:[{
n:'si786',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[776]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si776c:{
b:[169,477,203,497],
fh:false,
fw:false,
uid:776,
iso:false,
css:{
360:{
l:'17.387%',
t:'78.454%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'17.387%',
lhID:-1,
lvEID:0,
lvV:'78.454%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'17.387%',
t:'78.454%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'17.387%',
lhID:-1,
lvEID:0,
lvV:'78.454%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'17.387%',
t:'78.454%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'17.387%',
lhID:-1,
lvEID:0,
lvV:'78.454%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si776',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[169,477,203,497],
vb:[169,477,203,497]
},
si786:{
name:'Shape_3',
type:612,
from:1126,
to:1806,
rp:0,
rpa:0,
mdi:'si786c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[786]
}
]
,
stis:0,
bstiid:776,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si776',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si786c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:786,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si786',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si796:{
name:'Rectangle_4',
type:612,
from:9001,
to:9681,
rp:0,
rpa:0,
mdi:'si796c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":184,"width":300,"height":"auto"}}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:807,
stt:0,
dsr:'Default_State',
stsi:[796]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si796','si809','si820','si831'],
isDD:false
},
si796c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:796,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si796',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si809:{
name:'',
type:612,
from:1126,
to:1806,
rp:0,
rpa:0,
mdi:'si809c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":184,"width":300,"height":"auto"}}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si796',
stl:[{
stn:'Normal',
stt:0,
stsi:[809]
}
]
,
stis:0,
bstiid:796,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:796,
isDD:false
},
si809c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:809,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si809',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si820:{
name:'',
type:612,
from:1126,
to:1806,
rp:0,
rpa:0,
mdi:'si820c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":184,"width":300,"height":"auto"}}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si796',
stl:[{
stn:'Normal',
stt:0,
stsi:[820]
}
]
,
stis:0,
bstiid:796,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:796,
isDD:false
},
si820c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:820,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si820',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si831:{
name:'',
type:612,
from:1126,
to:1806,
rp:0,
rpa:0,
mdi:'si831c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":537,"left":184,"width":300,"height":"auto"}}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si796',
stl:[{
stn:'Normal',
stt:0,
stsi:[831]
}
]
,
stis:0,
bstiid:796,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:796,
isDD:false
},
si831c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:831,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si831',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3260:{
name:'Instructions_3',
type:612,
from:1126,
to:1806,
rp:0,
rpa:0,
mdi:'si3260c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:22.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Click on the top left corner template with the word \\"Quotes\\" in it.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":67,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":67,"style":"hlnkt:wp"},{"offset":0,"length":67,"style":"textOutlineEnable:false"},{"offset":0,"length":67,"style":"opacity:1"},{"offset":0,"length":67,"style":"textShadowColor:ffffff00"},{"offset":0,"length":67,"style":"hlnke:true"},{"offset":0,"length":67,"style":"backgroundColor:unset"},{"offset":0,"length":67,"style":"textShadowX:0px"},{"offset":0,"length":67,"style":"textShadowY:0px"},{"offset":0,"length":67,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":67,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":67,"style":"textShadowBlur:0px"},{"offset":0,"length":67,"style":"textHighlightEnable:false"},{"offset":0,"length":67,"style":"textShadowEnable:false"},{"offset":0,"length":67,"style":"hlnk:"},{"offset":0,"length":67,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":76.76243093922652,"top":312.0497237569061,"width":360.0443634539019},"shouldRender":true}',
parentGroup:'si757',
retainState:false,
immo:false,
apsn:'Slide739',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3260]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3260c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3260,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3260',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide739:{
lb:'Simulation slide 4',
id:739,
from:9001,
to:9681,
iols:0,
i360qs:false,
sdu:22.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide739c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si765',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
849:{
ts:''
}

}

},
Slide739c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:739,
dn:'Slide739',
visible:'1'
},
si882:{
name:'Simulation_5',
type:1268,
from:9682,
to:10079,
rp:0,
rpa:0,
mdi:'si882c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si874',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si882c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:882,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si882',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si874:{
name:'Simulation_non_responsive_5',
type:1268,
from:9682,
to:10079,
rp:0,
rpa:0,
mdi:'si874c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si882',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si893',
t:1269
}
,{
n:'si913',
t:612
}
,{
n:'si3270',
t:612
}
,{
n:'si3280',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si882',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si874c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:874,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si874',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:890,
tsp:50,
ip:'dr/0890.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si893:{
name:'Click_box_4',
type:1269,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si893c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":585.232044198895,"left":421,"width":61.6242635315953,"height":86.29292019164363},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(966);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:13.239,
lcapid:'si913',
si:[{
n:'si903',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[893]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si893c:{
b:[421,617,455,637],
fh:false,
fw:false,
uid:893,
iso:false,
css:{
360:{
l:'43.313%',
t:'101.480%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'43.313%',
lhID:-1,
lvEID:0,
lvV:'101.480%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'43.313%',
t:'101.480%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'43.313%',
lhID:-1,
lvEID:0,
lvV:'101.480%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'43.313%',
t:'101.480%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'43.313%',
lhID:-1,
lvEID:0,
lvV:'101.480%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si893',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[421,617,455,637],
vb:[421,617,455,637]
},
si903:{
name:'Shape_4',
type:612,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si903c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[903]
}
]
,
stis:0,
bstiid:893,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si893',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si903c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:903,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si903',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si913:{
name:'Rectangle_5',
type:612,
from:9682,
to:10079,
rp:0,
rpa:0,
mdi:'si913c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":677,"left":436,"width":300,"height":"auto"}}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:924,
stt:0,
dsr:'Default_State',
stsi:[913]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si913','si926','si937','si948'],
isDD:false
},
si913c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:913,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si913',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si926:{
name:'',
type:612,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si926c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":677,"left":436,"width":300,"height":"auto"}}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si913',
stl:[{
stn:'Normal',
stt:0,
stsi:[926]
}
]
,
stis:0,
bstiid:913,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:913,
isDD:false
},
si926c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:926,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si926',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si937:{
name:'',
type:612,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si937c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":677,"left":436,"width":300,"height":"auto"}}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si913',
stl:[{
stn:'Normal',
stt:0,
stsi:[937]
}
]
,
stis:0,
bstiid:913,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:913,
isDD:false
},
si937c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:937,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si937',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si948:{
name:'',
type:612,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si948c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":677,"left":436,"width":300,"height":"auto"}}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si913',
stl:[{
stn:'Normal',
stt:0,
stsi:[948]
}
]
,
stis:0,
bstiid:913,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:913,
isDD:false
},
si948c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:948,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si948',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3270:{
name:'Instructions_4',
type:612,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si3270c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Click on the center arrow to close the design area","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":50,"style":"hlnkt:wp"},{"offset":0,"length":50,"style":"textOutlineEnable:false"},{"offset":0,"length":50,"style":"opacity:1"},{"offset":0,"length":50,"style":"textShadowColor:ffffff00"},{"offset":0,"length":50,"style":"hlnke:true"},{"offset":0,"length":50,"style":"backgroundColor:unset"},{"offset":0,"length":50,"style":"textShadowX:0px"},{"offset":0,"length":50,"style":"textShadowY:0px"},{"offset":0,"length":50,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":50,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":50,"style":"textShadowBlur:0px"},{"offset":0,"length":50,"style":"textHighlightEnable:false"},{"offset":0,"length":50,"style":"textShadowEnable:false"},{"offset":0,"length":50,"style":"hlnk:"},{"offset":0,"length":50,"style":"overridden:false"},{"offset":0,"length":50,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":438.0939226519337,"top":493.3756906077348,"width":259.2265092206923},"shouldRender":true}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3270]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3270c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3270,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3270',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3280:{
name:'Mouse_2',
type:12,
from:1807,
to:2204,
rp:0,
rpa:0,
mdi:'si3280c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":16,"mouseStartPointY":16,"mouseEndPointX":16,"mouseEndPointY":16}}',
parentGroup:'si874',
retainState:false,
immo:false,
apsn:'Slide856',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si3280Ad',
trin:0,
trout:0,
isDD:false
},
si3280c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3280,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'1px',
h:'1px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3280',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si3280Ad:{
src:'ar/Mouse.mp3',
from:1807,
to:1812,
del:13.018,
msa:1,
du:0.182
},
Slide856:{
lb:'Simulation slide 5',
id:856,
from:9682,
to:10079,
iols:0,
i360qs:false,
sdu:13.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide856c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si882',
t:1268
}
]
,
iph:[]
,
oa:'si3280Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
966:{
ts:''
}

}

},
Slide856c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:856,
dn:'Slide856',
visible:'1'
},
si999:{
name:'Simulation_6',
type:1268,
from:2205,
to:2204,
rp:0,
rpa:0,
mdi:'si999c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide973',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si991',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si999c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:999,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si999',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si991:{
name:'Simulation_non_responsive_6',
type:1268,
from:2205,
to:2204,
rp:0,
rpa:0,
mdi:'si991c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si999',
retainState:false,
immo:false,
apsn:'Slide973',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si999',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si991c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:991,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si991',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1007,
tsp:50,
ip:'dr/01007.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide973:{
lb:'Simulation slide 6',
id:973,
from:2205,
to:2410,
iols:0,
i360qs:false,
sdu:6.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide973c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si999',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide973c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:973,
dn:'Slide973',
visible:'1'
},
si1036:{
name:'Simulation_7',
type:1268,
from:2411,
to:2410,
rp:0,
rpa:0,
mdi:'si1036c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1010',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1028',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1036c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1036,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1036',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1028:{
name:'Simulation_non_responsive_7',
type:1268,
from:2411,
to:2410,
rp:0,
rpa:0,
mdi:'si1028c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1036',
retainState:false,
immo:false,
apsn:'Slide1010',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1036',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1028c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1028,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1028',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1044,
tsp:50,
ip:'dr/01044.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide1010:{
lb:'Simulation slide 7',
id:1010,
from:2411,
to:2559,
iols:0,
i360qs:false,
sdu:5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1010c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1036',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1010c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1010,
dn:'Slide1010',
visible:'1'
},
si1073:{
name:'Simulation_8',
type:1268,
from:10080,
to:10639,
rp:0,
rpa:0,
mdi:'si1073c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1065',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1073c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1073,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1073',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1065:{
name:'Simulation_non_responsive_8',
type:1268,
from:10080,
to:10639,
rp:0,
rpa:0,
mdi:'si1065c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1073',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1084',
t:1269
}
,{
n:'si1104',
t:612
}
,{
n:'si3287',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1073',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1065c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1065,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1065',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1081,
tsp:50,
ip:'dr/01081.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1084:{
name:'Click_box_5',
type:1269,
from:2560,
to:3119,
rp:0,
rpa:0,
mdi:'si1084c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":587.3756906077348,"left":593.4585635359116,"width":314.38290084923165,"height":80.76169345918939},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1065',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1157);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:18.632,
lcapid:'si1104',
si:[{
n:'si1094',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1084]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1084c:{
b:[686,615,720,635],
fh:false,
fw:false,
uid:1084,
iso:false,
css:{
360:{
l:'70.576%',
t:'101.151%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'70.576%',
lhID:-1,
lvEID:0,
lvV:'101.151%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'70.576%',
t:'101.151%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'70.576%',
lhID:-1,
lvEID:0,
lvV:'101.151%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'70.576%',
t:'101.151%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'70.576%',
lhID:-1,
lvEID:0,
lvV:'101.151%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1084',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[686,615,720,635],
vb:[686,615,720,635]
},
si1094:{
name:'Shape_5',
type:612,
from:2560,
to:3119,
rp:0,
rpa:0,
mdi:'si1094c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1094]
}
]
,
stis:0,
bstiid:1084,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1084',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1094c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1094,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1094',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1104:{
name:'Rectangle_6',
type:612,
from:10080,
to:10639,
rp:0,
rpa:0,
mdi:'si1104c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":675,"left":701,"width":300,"height":"auto"}}',
parentGroup:'si1065',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1115,
stt:0,
dsr:'Default_State',
stsi:[1104]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1104','si1117','si1128','si1139'],
isDD:false
},
si1104c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1104,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1104',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1117:{
name:'',
type:612,
from:2560,
to:3119,
rp:0,
rpa:0,
mdi:'si1117c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":675,"left":701,"width":300,"height":"auto"}}',
parentGroup:'si1065',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1104',
stl:[{
stn:'Normal',
stt:0,
stsi:[1117]
}
]
,
stis:0,
bstiid:1104,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1104,
isDD:false
},
si1117c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1117,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1117',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1128:{
name:'',
type:612,
from:2560,
to:3119,
rp:0,
rpa:0,
mdi:'si1128c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":675,"left":701,"width":300,"height":"auto"}}',
parentGroup:'si1065',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1104',
stl:[{
stn:'Normal',
stt:0,
stsi:[1128]
}
]
,
stis:0,
bstiid:1104,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1104,
isDD:false
},
si1128c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1128,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1128',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1139:{
name:'',
type:612,
from:2560,
to:3119,
rp:0,
rpa:0,
mdi:'si1139c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":675,"left":701,"width":300,"height":"auto"}}',
parentGroup:'si1065',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1104',
stl:[{
stn:'Normal',
stt:0,
stsi:[1139]
}
]
,
stis:0,
bstiid:1104,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1104,
isDD:false
},
si1139c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1139,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1139',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3287:{
name:'Instructions_5',
type:612,
from:2560,
to:3119,
rp:0,
rpa:0,
mdi:'si3287c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:18.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Double click the text box here >>>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"textShadowColor:ffffff00"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"textShadowX:0px"},{"offset":0,"length":34,"style":"textShadowY:0px"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":34,"style":"textShadowBlur:0px"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"overridden:false"},{"offset":0,"length":34,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":177.76795580110496,"top":601.6187845303867,"width":357.29284971458475},"shouldRender":true}',
parentGroup:'si1065',
retainState:false,
immo:false,
apsn:'Slide1047',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3287]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3287c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3287,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3287',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1047:{
lb:'Simulation slide 8',
id:1047,
from:10080,
to:10639,
iols:0,
i360qs:false,
sdu:18.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1047c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1073',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1157:{
ts:''
}

}

},
Slide1047c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1047,
dn:'Slide1047',
visible:'1'
},
si1190:{
name:'Simulation_9',
type:1268,
from:3120,
to:3119,
rp:0,
rpa:0,
mdi:'si1190c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1164',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1182',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1190c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1190,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1190',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1182:{
name:'Simulation_non_responsive_9',
type:1268,
from:3120,
to:3119,
rp:0,
rpa:0,
mdi:'si1182c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1190',
retainState:false,
immo:false,
apsn:'Slide1164',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1190',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1182c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1182,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1182',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1198,
tsp:50,
ip:'dr/01198.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide1164:{
lb:'Simulation slide 9',
id:1164,
from:3120,
to:3366,
iols:0,
i360qs:false,
sdu:8.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1164c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1190',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1164c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1164,
dn:'Slide1164',
visible:'1'
},
si1227:{
name:'Simulation_10',
type:1268,
from:10640,
to:10686,
rp:0,
rpa:0,
mdi:'si1227c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1219',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1227c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1227,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1227',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1219:{
name:'Simulation_non_responsive_10',
type:1268,
from:10640,
to:10686,
rp:0,
rpa:0,
mdi:'si1219c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":true,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1227',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1238',
t:2433
}
,{
n:'si1268',
t:612
}
,{
n:'si3297',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":true,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1227',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1219c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1219,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1219',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1235,
tsp:50,
ip:'dr/01235.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1238:{
name:'InputField_2',
type:2433,
from:10640,
to:10686,
rp:0,
rpa:0,
mdi:'si1238c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[1266,1267],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"inputFieldProps":{"answersList":["."],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":false,"error":false},"active":{"opacity":100,"editorState":{"blocks":[{"key":"t7ru","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"attempts":1024,"normal":{"opacity":100,"editorState":{"blocks":[{"key":"3u77k","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"scaleValue":"medium","sizeNPos":{"top":586,"left":584,"width":327,"height":124},"error":{"opacity":100,"editorState":{"blocks":[{"key":"cducb","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"8"}},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","currentState":"active","focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"1b65o","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"s16q","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"isTextActive":true}',
parentGroup:'si1219',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
ofov:'{"scripts":[{"then":[["cp.jumpToNextSlide(1315);"]]}]}',
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:['.'],
si:[]
,
te:true,
ie:false,
lcapid:'si1268',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1238]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1238c:{
b:[584,586,911,710],
fh:false,
fw:false,
uid:1238,
iso:false,
css:{
360:{
l:'60.082%',
t:'96.382%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'60.082%',
lhID:-1,
lvEID:0,
lvV:'96.382%',
lvID:-1,
w:'33.642%',
h:'20.395%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'60.082%',
t:'96.382%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'60.082%',
lhID:-1,
lvEID:0,
lvV:'96.382%',
lvID:-1,
w:'33.642%',
h:'20.395%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'60.082%',
t:'96.382%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'60.082%',
lhID:-1,
lvEID:0,
lvV:'96.382%',
lvID:-1,
w:'33.642%',
h:'20.395%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1238',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[584,586,911,710],
vb:[584,586,911,710]
},
si1268:{
name:'Rectangle_7',
type:612,
from:3367,
to:3413,
rp:0,
rpa:0,
mdi:'si1268c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":646,"left":599,"width":300,"height":"auto"}}',
parentGroup:'si1219',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1279,
stt:0,
dsr:'Default_State',
stsi:[1268]
}
,{
stn:1291,
stt:102,
dsr:'Failure',
stsi:[1292]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1268','si1281','si1292','si1303'],
isDD:false
},
si1268c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1268,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1268',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1281:{
name:'',
type:612,
from:3367,
to:3413,
rp:0,
rpa:0,
mdi:'si1281c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":646,"left":599,"width":300,"height":"auto"}}',
parentGroup:'si1219',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1268',
stl:[{
stn:'Normal',
stt:0,
stsi:[1281]
}
]
,
stis:0,
bstiid:1268,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1268,
isDD:false
},
si1281c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1281,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1281',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1292:{
name:'',
type:612,
from:3367,
to:3413,
rp:0,
rpa:0,
mdi:'si1292c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":646,"left":599,"width":300,"height":"auto"}}',
parentGroup:'si1219',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1268',
stl:[{
stn:'Normal',
stt:0,
stsi:[1292]
}
]
,
stis:0,
bstiid:1268,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1268,
isDD:false
},
si1292c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1292,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1292',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1303:{
name:'',
type:612,
from:3367,
to:3413,
rp:0,
rpa:0,
mdi:'si1303c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":646,"left":599,"width":300,"height":"auto"}}',
parentGroup:'si1219',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1268',
stl:[{
stn:'Normal',
stt:0,
stsi:[1303]
}
]
,
stis:0,
bstiid:1268,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1268,
isDD:false
},
si1303c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1303,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1303',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3297:{
name:'Instructions_6',
type:612,
from:3367,
to:3413,
rp:0,
rpa:0,
mdi:'si3297c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Paste or type in the quote that you want to use in this text box. >>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":68,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":68,"style":"hlnkt:wp"},{"offset":0,"length":68,"style":"textOutlineEnable:false"},{"offset":0,"length":68,"style":"opacity:1"},{"offset":0,"length":68,"style":"textShadowColor:ffffff00"},{"offset":0,"length":68,"style":"hlnke:true"},{"offset":0,"length":68,"style":"backgroundColor:unset"},{"offset":0,"length":68,"style":"textShadowX:0px"},{"offset":0,"length":68,"style":"textShadowY:0px"},{"offset":0,"length":68,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":68,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":68,"style":"textShadowBlur:0px"},{"offset":0,"length":68,"style":"textHighlightEnable:false"},{"offset":0,"length":68,"style":"textShadowEnable:false"},{"offset":0,"length":68,"style":"hlnk:"},{"offset":0,"length":68,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":189.91160220994476,"top":609.4751381215469,"width":340.7182219278746},"shouldRender":true}',
parentGroup:'si1219',
retainState:false,
immo:false,
apsn:'Slide1201',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3297]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3297c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3297,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3297',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1201:{
lb:'Simulation slide 10',
id:1201,
from:10640,
to:10686,
iols:0,
i360qs:false,
sdu:1.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1201c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1227',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1315:{
ts:''
}

}

},
Slide1201c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1201,
dn:'Slide1201',
visible:'1'
},
si1342:{
name:'Simulation_11',
type:1268,
from:10687,
to:11219,
rp:0,
rpa:0,
mdi:'si1342c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1334',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1342c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1342,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1342',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1334:{
name:'Simulation_non_responsive_11',
type:1268,
from:10687,
to:11219,
rp:0,
rpa:0,
mdi:'si1334c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1342',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1353',
t:1269
}
,{
n:'si1373',
t:612
}
,{
n:'si3307',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1342',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1334c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1334,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1334',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1350,
tsp:50,
ip:'dr/01350.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1353:{
name:'Click_box_6',
type:1269,
from:3414,
to:3946,
rp:0,
rpa:0,
mdi:'si1353c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":506.9502762430939,"left":688.2872928176796,"width":118.25418208844094,"height":44.84941682762862},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1334',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1426);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:17.745,
lcapid:'si1373',
si:[{
n:'si1363',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1353]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1353c:{
b:[680,521,714,541],
fh:false,
fw:false,
uid:1353,
iso:false,
css:{
360:{
l:'69.959%',
t:'85.691%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'69.959%',
lhID:-1,
lvEID:0,
lvV:'85.691%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'69.959%',
t:'85.691%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'69.959%',
lhID:-1,
lvEID:0,
lvV:'85.691%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'69.959%',
t:'85.691%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'69.959%',
lhID:-1,
lvEID:0,
lvV:'85.691%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1353',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[680,521,714,541],
vb:[680,521,714,541]
},
si1363:{
name:'Shape_6',
type:612,
from:3414,
to:3946,
rp:0,
rpa:0,
mdi:'si1363c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1363]
}
]
,
stis:0,
bstiid:1353,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1353',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1363c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1363,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1363',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1373:{
name:'Rectangle_8',
type:612,
from:10687,
to:11219,
rp:0,
rpa:0,
mdi:'si1373c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":581,"left":695,"width":300,"height":"auto"}}',
parentGroup:'si1334',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1384,
stt:0,
dsr:'Default_State',
stsi:[1373]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1373','si1386','si1397','si1408'],
isDD:false
},
si1373c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1373,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1373',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1386:{
name:'',
type:612,
from:3414,
to:3946,
rp:0,
rpa:0,
mdi:'si1386c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":581,"left":695,"width":300,"height":"auto"}}',
parentGroup:'si1334',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1373',
stl:[{
stn:'Normal',
stt:0,
stsi:[1386]
}
]
,
stis:0,
bstiid:1373,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1373,
isDD:false
},
si1386c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1386,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1386',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1397:{
name:'',
type:612,
from:3414,
to:3946,
rp:0,
rpa:0,
mdi:'si1397c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":581,"left":695,"width":300,"height":"auto"}}',
parentGroup:'si1334',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1373',
stl:[{
stn:'Normal',
stt:0,
stsi:[1397]
}
]
,
stis:0,
bstiid:1373,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1373,
isDD:false
},
si1397c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1397,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1397',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1408:{
name:'',
type:612,
from:3414,
to:3946,
rp:0,
rpa:0,
mdi:'si1408c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":581,"left":695,"width":300,"height":"auto"}}',
parentGroup:'si1334',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1373',
stl:[{
stn:'Normal',
stt:0,
stsi:[1408]
}
]
,
stis:0,
bstiid:1373,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1373,
isDD:false
},
si1408c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1408,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1408',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3307:{
name:'Instructions_7',
type:612,
from:3414,
to:3946,
rp:0,
rpa:0,
mdi:'si3307c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:17.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Double-click on \\"Quotes.\\" >>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"textShadowColor:ffffff00"},{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"textShadowX:0px"},{"offset":0,"length":28,"style":"textShadowY:0px"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":28,"style":"textShadowBlur:0px"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"overridden:false"},{"offset":0,"length":28,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":327.61878453038673,"top":506.95580110497235,"width":320},"shouldRender":true}',
parentGroup:'si1334',
retainState:false,
immo:false,
apsn:'Slide1316',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3307]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3307c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3307,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3307',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1316:{
lb:'Simulation slide 11',
id:1316,
from:10687,
to:11219,
iols:0,
i360qs:false,
sdu:17.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1316c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1342',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1426:{
ts:''
}

}

},
Slide1316c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1316,
dn:'Slide1316',
visible:'1'
},
si1459:{
name:'Simulation_12',
type:1268,
from:11220,
to:11373,
rp:0,
rpa:0,
mdi:'si1459c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1451',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1459c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1459,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1459',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1451:{
name:'Simulation_non_responsive_12',
type:1268,
from:11220,
to:11373,
rp:0,
rpa:0,
mdi:'si1451c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":true,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1459',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1470',
t:2433
}
,{
n:'si1500',
t:612
}
,{
n:'si3317',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":true,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1459',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1451c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1451,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1451',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1467,
tsp:50,
ip:'dr/01467.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1470:{
name:'InputField_3',
type:2433,
from:11220,
to:11373,
rp:0,
rpa:0,
mdi:'si1470c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[1498,1499],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"inputFieldProps":{"answersList":["Maya Angelou"],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":false,"error":false},"active":{"opacity":100,"editorState":{"blocks":[{"key":"t7ru","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"attempts":1024,"normal":{"opacity":100,"editorState":{"blocks":[{"key":"3u77k","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"scaleValue":"medium","sizeNPos":{"top":500,"left":538,"width":311,"height":88},"error":{"opacity":100,"editorState":{"blocks":[{"key":"cducb","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"8"}},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","currentState":"normal","focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"1b65o","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"s16q","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"isTextActive":true}',
parentGroup:'si1451',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
ofov:'{"scripts":[{"then":[["cp.jumpToNextSlide(1547);"]]}]}',
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:['Maya Angelou'],
si:[]
,
te:true,
ie:false,
lcapid:'si1500',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1470]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1470c:{
b:[538,500,849,588],
fh:false,
fw:false,
uid:1470,
iso:false,
css:{
360:{
l:'55.350%',
t:'82.237%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'55.350%',
lhID:-1,
lvEID:0,
lvV:'82.237%',
lvID:-1,
w:'31.996%',
h:'14.474%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'55.350%',
t:'82.237%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'55.350%',
lhID:-1,
lvEID:0,
lvV:'82.237%',
lvID:-1,
w:'31.996%',
h:'14.474%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'55.350%',
t:'82.237%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'55.350%',
lhID:-1,
lvEID:0,
lvV:'82.237%',
lvID:-1,
w:'31.996%',
h:'14.474%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1470',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[538,500,849,588],
vb:[538,500,849,588]
},
si1500:{
name:'Rectangle_9',
type:612,
from:3947,
to:4100,
rp:0,
rpa:0,
mdi:'si1500c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":560,"left":553,"width":300,"height":"auto"}}',
parentGroup:'si1451',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1511,
stt:0,
dsr:'Default_State',
stsi:[1500]
}
,{
stn:1523,
stt:102,
dsr:'Failure',
stsi:[1524]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1500','si1513','si1524','si1535'],
isDD:false
},
si1500c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1500,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1500',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1513:{
name:'',
type:612,
from:3947,
to:4100,
rp:0,
rpa:0,
mdi:'si1513c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":560,"left":553,"width":300,"height":"auto"}}',
parentGroup:'si1451',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1500',
stl:[{
stn:'Normal',
stt:0,
stsi:[1513]
}
]
,
stis:0,
bstiid:1500,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1500,
isDD:false
},
si1513c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1513,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1513',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1524:{
name:'',
type:612,
from:3947,
to:4100,
rp:0,
rpa:0,
mdi:'si1524c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":560,"left":553,"width":300,"height":"auto"}}',
parentGroup:'si1451',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1500',
stl:[{
stn:'Normal',
stt:0,
stsi:[1524]
}
]
,
stis:0,
bstiid:1500,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1500,
isDD:false
},
si1524c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1524,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1524',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1535:{
name:'',
type:612,
from:3947,
to:4100,
rp:0,
rpa:0,
mdi:'si1535c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":560,"left":553,"width":300,"height":"auto"}}',
parentGroup:'si1451',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1500',
stl:[{
stn:'Normal',
stt:0,
stsi:[1535]
}
]
,
stis:0,
bstiid:1500,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1500,
isDD:false
},
si1535c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1535,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1535',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3317:{
name:'Instructions_8',
type:612,
from:3947,
to:4100,
rp:0,
rpa:0,
mdi:'si3317c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Type your author\'s name. >>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"textShadowColor:ffffff00"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"textShadowX:0px"},{"offset":0,"length":27,"style":"textShadowY:0px"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":27,"style":"textShadowBlur:0px"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":195.43093922651934,"top":496.8563535911602,"width":320},"shouldRender":true}',
parentGroup:'si1451',
retainState:false,
immo:false,
apsn:'Slide1433',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3317]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3317c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3317,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3317',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1433:{
lb:'Simulation slide 12',
id:1433,
from:11220,
to:11373,
iols:0,
i360qs:false,
sdu:5.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1433c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1459',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1547:{
ts:''
}

}

},
Slide1433c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1433,
dn:'Slide1433',
visible:'1'
},
si1574:{
name:'Simulation_13',
type:1268,
from:11374,
to:11985,
rp:0,
rpa:0,
mdi:'si1574c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1566',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1574c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1574,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1574',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1566:{
name:'Simulation_non_responsive_13',
type:1268,
from:11374,
to:11985,
rp:0,
rpa:0,
mdi:'si1566c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1574',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1585',
t:1269
}
,{
n:'si1605',
t:612
}
,{
n:'si3327',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1574',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1566c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1566,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1566',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1582,
tsp:50,
ip:'dr/01582.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1585:{
name:'Click_box_7',
type:1269,
from:4101,
to:4712,
rp:0,
rpa:0,
mdi:'si1585c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":536,"left":643,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1566',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1658);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:20.36,
lcapid:'si1605',
si:[{
n:'si1595',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1585]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1585c:{
b:[643,536,677,556],
fh:false,
fw:false,
uid:1585,
iso:false,
css:{
360:{
l:'66.152%',
t:'88.158%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.152%',
lhID:-1,
lvEID:0,
lvV:'88.158%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'66.152%',
t:'88.158%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.152%',
lhID:-1,
lvEID:0,
lvV:'88.158%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'66.152%',
t:'88.158%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.152%',
lhID:-1,
lvEID:0,
lvV:'88.158%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1585',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[643,536,677,556],
vb:[643,536,677,556]
},
si1595:{
name:'Shape_7',
type:612,
from:4101,
to:4712,
rp:0,
rpa:0,
mdi:'si1595c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1595]
}
]
,
stis:0,
bstiid:1585,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1585',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1595c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1595,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1595',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1605:{
name:'Rectangle_10',
type:612,
from:11374,
to:11985,
rp:0,
rpa:0,
mdi:'si1605c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":596,"left":658,"width":300,"height":"auto"}}',
parentGroup:'si1566',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1616,
stt:0,
dsr:'Default_State',
stsi:[1605]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1605','si1618','si1629','si1640'],
isDD:false
},
si1605c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1605,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1605',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1618:{
name:'',
type:612,
from:4101,
to:4712,
rp:0,
rpa:0,
mdi:'si1618c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":596,"left":658,"width":300,"height":"auto"}}',
parentGroup:'si1566',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1605',
stl:[{
stn:'Normal',
stt:0,
stsi:[1618]
}
]
,
stis:0,
bstiid:1605,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1605,
isDD:false
},
si1618c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1618,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1618',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1629:{
name:'',
type:612,
from:4101,
to:4712,
rp:0,
rpa:0,
mdi:'si1629c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":596,"left":658,"width":300,"height":"auto"}}',
parentGroup:'si1566',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1605',
stl:[{
stn:'Normal',
stt:0,
stsi:[1629]
}
]
,
stis:0,
bstiid:1605,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1605,
isDD:false
},
si1629c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1629,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1629',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1640:{
name:'',
type:612,
from:4101,
to:4712,
rp:0,
rpa:0,
mdi:'si1640c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":596,"left":658,"width":300,"height":"auto"}}',
parentGroup:'si1566',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1605',
stl:[{
stn:'Normal',
stt:0,
stsi:[1640]
}
]
,
stis:0,
bstiid:1605,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1605,
isDD:false
},
si1640c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1640,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1640',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3327:{
name:'Instructions_9',
type:612,
from:4101,
to:4712,
rp:0,
rpa:0,
mdi:'si3327c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:20.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"If you need to make room for the name, stretch the text box using the left center marker of the text box. Slowly pull the marker away from the name to help it fit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":163,"style":"hlnkt:wp"},{"offset":0,"length":163,"style":"textOutlineEnable:false"},{"offset":0,"length":163,"style":"opacity:1"},{"offset":0,"length":163,"style":"textShadowColor:ffffff00"},{"offset":0,"length":163,"style":"hlnke:true"},{"offset":0,"length":163,"style":"backgroundColor:unset"},{"offset":0,"length":163,"style":"textShadowX:0px"},{"offset":0,"length":163,"style":"textShadowY:0px"},{"offset":0,"length":163,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":163,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":163,"style":"textShadowBlur:0px"},{"offset":0,"length":163,"style":"textHighlightEnable:false"},{"offset":0,"length":163,"style":"textShadowEnable:false"},{"offset":0,"length":163,"style":"hlnk:"},{"offset":0,"length":163,"style":"overridden:false"},{"offset":0,"length":163,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":210.6243093922652,"top":449.1767955801105,"width":320},"shouldRender":true}',
parentGroup:'si1566',
retainState:false,
immo:false,
apsn:'Slide1548',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3327]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3327c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3327,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3327',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1548:{
lb:'Simulation slide 13',
id:1548,
from:11374,
to:11985,
iols:0,
i360qs:false,
sdu:20.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1548c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1574',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1658:{
ts:''
}

}

},
Slide1548c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1548,
dn:'Slide1548',
visible:'1'
},
si1691:{
name:'Simulation_14',
type:1268,
from:4713,
to:4712,
rp:0,
rpa:0,
mdi:'si1691c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1665',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1683',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1691c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1691,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1691',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1683:{
name:'Simulation_non_responsive_14',
type:1268,
from:4713,
to:4712,
rp:0,
rpa:0,
mdi:'si1683c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1691',
retainState:false,
immo:false,
apsn:'Slide1665',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1691',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1683c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1683,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1683',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1699,
tsp:50,
ip:'dr/01699.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide1665:{
lb:'Simulation slide 14',
id:1665,
from:4713,
to:4744,
iols:0,
i360qs:false,
sdu:1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1665c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1691',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1665c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1665,
dn:'Slide1665',
visible:'1'
},
si1809:{
name:'Simulation_16',
type:1268,
from:11986,
to:12156,
rp:0,
rpa:0,
mdi:'si1809c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1801',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1809c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1809,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1809',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1801:{
name:'Simulation_non_responsive_16',
type:1268,
from:11986,
to:12156,
rp:0,
rpa:0,
mdi:'si1801c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1809',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1820',
t:1269
}
,{
n:'si1840',
t:612
}
,{
n:'si3337',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1809',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1801c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1801,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1801',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1817,
tsp:50,
ip:'dr/01817.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1820:{
name:'Click_box_8',
type:1269,
from:4745,
to:4915,
rp:0,
rpa:0,
mdi:'si1820c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":595.5027624309392,"left":1126,"width":184.540469343491,"height":155.35415733716763},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1801',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1893);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:5.67901,
lcapid:'si1840',
si:[{
n:'si1830',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1820]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1820c:{
b:[1077,668,1111,688],
fh:false,
fw:false,
uid:1820,
iso:false,
css:{
360:{
l:'110.802%',
t:'109.868%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'110.802%',
lhID:-1,
lvEID:0,
lvV:'109.868%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'110.802%',
t:'109.868%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'110.802%',
lhID:-1,
lvEID:0,
lvV:'109.868%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'110.802%',
t:'109.868%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'110.802%',
lhID:-1,
lvEID:0,
lvV:'109.868%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1820',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1077,668,1111,688],
vb:[1077,668,1111,688]
},
si1830:{
name:'Shape_8',
type:612,
from:4745,
to:4915,
rp:0,
rpa:0,
mdi:'si1830c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1830]
}
]
,
stis:0,
bstiid:1820,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1820',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1830c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1830,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1830',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1840:{
name:'Rectangle_11',
type:612,
from:11986,
to:12156,
rp:0,
rpa:0,
mdi:'si1840c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":728,"left":1092,"width":300,"height":"auto"}}',
parentGroup:'si1801',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1851,
stt:0,
dsr:'Default_State',
stsi:[1840]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1840','si1853','si1864','si1875'],
isDD:false
},
si1840c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1840,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1840',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1853:{
name:'',
type:612,
from:4745,
to:4915,
rp:0,
rpa:0,
mdi:'si1853c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":728,"left":1092,"width":300,"height":"auto"}}',
parentGroup:'si1801',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1840',
stl:[{
stn:'Normal',
stt:0,
stsi:[1853]
}
]
,
stis:0,
bstiid:1840,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1840,
isDD:false
},
si1853c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1853,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1853',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1864:{
name:'',
type:612,
from:4745,
to:4915,
rp:0,
rpa:0,
mdi:'si1864c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":728,"left":1092,"width":300,"height":"auto"}}',
parentGroup:'si1801',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1840',
stl:[{
stn:'Normal',
stt:0,
stsi:[1864]
}
]
,
stis:0,
bstiid:1840,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1840,
isDD:false
},
si1864c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1864,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1864',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1875:{
name:'',
type:612,
from:4745,
to:4915,
rp:0,
rpa:0,
mdi:'si1875c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":728,"left":1092,"width":300,"height":"auto"}}',
parentGroup:'si1801',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1840',
stl:[{
stn:'Normal',
stt:0,
stsi:[1875]
}
]
,
stis:0,
bstiid:1840,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1840,
isDD:false
},
si1875c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1875,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1875',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3337:{
name:'Instructions_10',
type:612,
from:4745,
to:4915,
rp:0,
rpa:0,
mdi:'si3337c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"^^","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"ct6ho","text":"Click outside of the text box here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"textShadowColor:ffffff00"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"textShadowX:0px"},{"offset":0,"length":34,"style":"textShadowY:0px"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":34,"style":"textShadowBlur:0px"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1124.6187845303868,"top":763.121546961326,"width":187.4031361953988},"shouldRender":true}',
parentGroup:'si1801',
retainState:false,
immo:false,
apsn:'Slide1783',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3337]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3337c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3337,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3337',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1783:{
lb:'Simulation slide 17',
id:1783,
from:11986,
to:12156,
iols:0,
i360qs:false,
sdu:5.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1783c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1809',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1893:{
ts:''
}

}

},
Slide1783c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1783,
dn:'Slide1783',
visible:'1'
},
si1926:{
name:'Simulation_17',
type:1268,
from:12157,
to:12731,
rp:0,
rpa:0,
mdi:'si1926c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1918',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1926c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1926,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1926',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1918:{
name:'Simulation_non_responsive_17',
type:1268,
from:12157,
to:12731,
rp:0,
rpa:0,
mdi:'si1918c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1926',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1937',
t:1269
}
,{
n:'si1957',
t:612
}
,{
n:'si3347',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1926',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1918c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1918,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1918',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1934,
tsp:50,
ip:'dr/01934.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1937:{
name:'Click_box_9',
type:1269,
from:4916,
to:5490,
rp:0,
rpa:0,
mdi:'si1937c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":875.2375690607735,"left":679,"width":138.97232982993782,"height":22.76248826506388},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si1918',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2010);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:19.129,
lcapid:'si1957',
si:[{
n:'si1947',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1937]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1937c:{
b:[752,877,786,897],
fh:false,
fw:false,
uid:1937,
iso:false,
css:{
360:{
l:'77.366%',
t:'144.243%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.366%',
lhID:-1,
lvEID:0,
lvV:'144.243%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'77.366%',
t:'144.243%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.366%',
lhID:-1,
lvEID:0,
lvV:'144.243%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'77.366%',
t:'144.243%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.366%',
lhID:-1,
lvEID:0,
lvV:'144.243%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1937',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[752,877,786,897],
vb:[752,877,786,897]
},
si1947:{
name:'Shape_9',
type:612,
from:4916,
to:5490,
rp:0,
rpa:0,
mdi:'si1947c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1947]
}
]
,
stis:0,
bstiid:1937,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1937',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1947c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1947,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1947',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1957:{
name:'Rectangle_12',
type:612,
from:12157,
to:12731,
rp:0,
rpa:0,
mdi:'si1957c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":937,"left":767,"width":300,"height":"auto"}}',
parentGroup:'si1918',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1968,
stt:0,
dsr:'Default_State',
stsi:[1957]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1957','si1970','si1981','si1992'],
isDD:false
},
si1957c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1957,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1957',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1970:{
name:'',
type:612,
from:4916,
to:5490,
rp:0,
rpa:0,
mdi:'si1970c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":937,"left":767,"width":300,"height":"auto"}}',
parentGroup:'si1918',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1957',
stl:[{
stn:'Normal',
stt:0,
stsi:[1970]
}
]
,
stis:0,
bstiid:1957,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1957,
isDD:false
},
si1970c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1970,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1970',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1981:{
name:'',
type:612,
from:4916,
to:5490,
rp:0,
rpa:0,
mdi:'si1981c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":937,"left":767,"width":300,"height":"auto"}}',
parentGroup:'si1918',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1957',
stl:[{
stn:'Normal',
stt:0,
stsi:[1981]
}
]
,
stis:0,
bstiid:1957,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1957,
isDD:false
},
si1981c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1981,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1981',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1992:{
name:'',
type:612,
from:4916,
to:5490,
rp:0,
rpa:0,
mdi:'si1992c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":937,"left":767,"width":300,"height":"auto"}}',
parentGroup:'si1918',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1957',
stl:[{
stn:'Normal',
stt:0,
stsi:[1992]
}
]
,
stis:0,
bstiid:1957,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1957,
isDD:false
},
si1992c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1992,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1992',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3347:{
name:'Instructions_11',
type:612,
from:4916,
to:5490,
rp:0,
rpa:0,
mdi:'si3347c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:19.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"^^","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"8p2g9","text":"Double-click on @reallygreatsite and highlight the word.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"textShadowColor:ffffff00"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"textShadowX:0px"},{"offset":0,"length":56,"style":"textShadowY:0px"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":56,"style":"textShadowBlur:0px"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":596.6187845303867,"top":907.2375690607736,"width":320},"shouldRender":true}',
parentGroup:'si1918',
retainState:false,
immo:false,
apsn:'Slide1900',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3347]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3347c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3347,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3347',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide1900:{
lb:'Simulation slide 18',
id:1900,
from:12157,
to:12731,
iols:0,
i360qs:false,
sdu:19.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1900c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1926',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2010:{
ts:''
}

}

},
Slide1900c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1900,
dn:'Slide1900',
visible:'1'
},
si2043:{
name:'Simulation_18',
type:1268,
from:12732,
to:13099,
rp:0,
rpa:0,
mdi:'si2043c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2035',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2043c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2043,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2043',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2035:{
name:'Simulation_non_responsive_18',
type:1268,
from:12732,
to:13099,
rp:0,
rpa:0,
mdi:'si2035c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":true,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2043',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2054',
t:2433
}
,{
n:'si2084',
t:612
}
,{
n:'si3357',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":true,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":1,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2043',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2035c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2035,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2035',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2051,
tsp:50,
ip:'dr/02051.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2054:{
name:'InputField_4',
type:2433,
from:12732,
to:13099,
rp:0,
rpa:0,
mdi:'si2054c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[2082,2083],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"inputFieldProps":{"answersList":["@mumsthewordca"],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":false,"error":false},"active":{"opacity":100,"editorState":{"blocks":[{"key":"t7ru","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"attempts":1024,"normal":{"opacity":100,"editorState":{"blocks":[{"key":"3u77k","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"scaleValue":"medium","sizeNPos":{"top":875,"left":636,"width":220,"height":25},"error":{"opacity":100,"editorState":{"blocks":[{"key":"cducb","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"8"}},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","currentState":"normal","focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"1b65o","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"s16q","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"isTextActive":true}',
parentGroup:'si2035',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
ofov:'{"scripts":[{"then":[["cp.jumpToNextSlide(2131);"]]}]}',
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:['@mumsthewordca'],
si:[]
,
te:true,
ie:false,
lcapid:'si2084',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2054]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2054c:{
b:[636,875,856,900],
fh:false,
fw:false,
uid:2054,
iso:false,
css:{
360:{
l:'65.432%',
t:'143.914%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'65.432%',
lhID:-1,
lvEID:0,
lvV:'143.914%',
lvID:-1,
w:'22.634%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'65.432%',
t:'143.914%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'65.432%',
lhID:-1,
lvEID:0,
lvV:'143.914%',
lvID:-1,
w:'22.634%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'65.432%',
t:'143.914%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'65.432%',
lhID:-1,
lvEID:0,
lvV:'143.914%',
lvID:-1,
w:'22.634%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2054',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[636,875,856,900],
vb:[636,875,856,900]
},
si2084:{
name:'Rectangle_13',
type:612,
from:5491,
to:5858,
rp:0,
rpa:0,
mdi:'si2084c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":651,"width":300,"height":"auto"}}',
parentGroup:'si2035',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2095,
stt:0,
dsr:'Default_State',
stsi:[2084]
}
,{
stn:2107,
stt:102,
dsr:'Failure',
stsi:[2108]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2084','si2097','si2108','si2119'],
isDD:false
},
si2084c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2084,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2084',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2097:{
name:'',
type:612,
from:5491,
to:5858,
rp:0,
rpa:0,
mdi:'si2097c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":651,"width":300,"height":"auto"}}',
parentGroup:'si2035',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2084',
stl:[{
stn:'Normal',
stt:0,
stsi:[2097]
}
]
,
stis:0,
bstiid:2084,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2084,
isDD:false
},
si2097c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2097,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2097',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2108:{
name:'',
type:612,
from:5491,
to:5858,
rp:0,
rpa:0,
mdi:'si2108c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":651,"width":300,"height":"auto"}}',
parentGroup:'si2035',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2084',
stl:[{
stn:'Normal',
stt:0,
stsi:[2108]
}
]
,
stis:0,
bstiid:2084,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2084,
isDD:false
},
si2108c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2108,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2108',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2119:{
name:'',
type:612,
from:5491,
to:5858,
rp:0,
rpa:0,
mdi:'si2119c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":651,"width":300,"height":"auto"}}',
parentGroup:'si2035',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2084',
stl:[{
stn:'Normal',
stt:0,
stsi:[2119]
}
]
,
stis:0,
bstiid:2084,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2084,
isDD:false
},
si2119c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2119,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2119',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3357:{
name:'Instructions_12',
type:612,
from:5491,
to:5858,
rp:0,
rpa:0,
mdi:'si3357c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:12.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"<<","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"26u1j","text":"Type your Instagram handle here.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":32,"style":"hlnkt:wp"},{"offset":0,"length":32,"style":"textOutlineEnable:false"},{"offset":0,"length":32,"style":"opacity:1"},{"offset":0,"length":32,"style":"textShadowColor:ffffff00"},{"offset":0,"length":32,"style":"hlnke:true"},{"offset":0,"length":32,"style":"backgroundColor:unset"},{"offset":0,"length":32,"style":"textShadowX:0px"},{"offset":0,"length":32,"style":"textShadowY:0px"},{"offset":0,"length":32,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":32,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":32,"style":"textShadowBlur:0px"},{"offset":0,"length":32,"style":"textHighlightEnable:false"},{"offset":0,"length":32,"style":"textShadowEnable:false"},{"offset":0,"length":32,"style":"hlnk:"},{"offset":0,"length":32,"style":"overridden:false"},{"offset":0,"length":32,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":871.6132596685082,"top":854.1988950276243,"width":335.1846768711153},"shouldRender":true}',
parentGroup:'si2035',
retainState:false,
immo:false,
apsn:'Slide2017',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3357]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3357c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3357,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3357',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2017:{
lb:'Simulation slide 19',
id:2017,
from:12732,
to:13099,
iols:0,
i360qs:false,
sdu:12.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2017c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2043',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2131:{
ts:''
}

}

},
Slide2017c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2017,
dn:'Slide2017',
visible:'1'
},
si2158:{
name:'Simulation_19',
type:1268,
from:13100,
to:13325,
rp:0,
rpa:0,
mdi:'si2158c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2150',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2158c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2158,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2158',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2150:{
name:'Simulation_non_responsive_19',
type:1268,
from:13100,
to:13325,
rp:0,
rpa:0,
mdi:'si2150c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2158',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2169',
t:1269
}
,{
n:'si2189',
t:612
}
,{
n:'si3367',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2158',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2150c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2150,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2150',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2166,
tsp:50,
ip:'dr/02166.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2169:{
name:'Click_box_10',
type:1269,
from:5859,
to:6084,
rp:0,
rpa:0,
mdi:'si2169c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":632.6408839779006,"left":1118.8066298342542,"width":203.88962550716505,"height":120.8287023049033},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2150',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2242);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:7.51301,
lcapid:'si2189',
si:[{
n:'si2179',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2169]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2169c:{
b:[1134,768,1168,788],
fh:false,
fw:false,
uid:2169,
iso:false,
css:{
360:{
l:'116.667%',
t:'126.316%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.667%',
lhID:-1,
lvEID:0,
lvV:'126.316%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'116.667%',
t:'126.316%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.667%',
lhID:-1,
lvEID:0,
lvV:'126.316%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'116.667%',
t:'126.316%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'116.667%',
lhID:-1,
lvEID:0,
lvV:'126.316%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2169',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1134,768,1168,788],
vb:[1134,768,1168,788]
},
si2179:{
name:'Shape_10',
type:612,
from:5859,
to:6084,
rp:0,
rpa:0,
mdi:'si2179c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2179]
}
]
,
stis:0,
bstiid:2169,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2169',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2179c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2179,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2179',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2189:{
name:'Rectangle_14',
type:612,
from:13100,
to:13325,
rp:0,
rpa:0,
mdi:'si2189c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":828,"left":819,"width":300,"height":"auto"}}',
parentGroup:'si2150',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2200,
stt:0,
dsr:'Default_State',
stsi:[2189]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2189','si2202','si2213','si2224'],
isDD:false
},
si2189c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2189,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2189',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2202:{
name:'',
type:612,
from:5859,
to:6084,
rp:0,
rpa:0,
mdi:'si2202c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":828,"left":819,"width":300,"height":"auto"}}',
parentGroup:'si2150',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2189',
stl:[{
stn:'Normal',
stt:0,
stsi:[2202]
}
]
,
stis:0,
bstiid:2189,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2189,
isDD:false
},
si2202c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2202,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2202',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2213:{
name:'',
type:612,
from:5859,
to:6084,
rp:0,
rpa:0,
mdi:'si2213c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":828,"left":819,"width":300,"height":"auto"}}',
parentGroup:'si2150',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2189',
stl:[{
stn:'Normal',
stt:0,
stsi:[2213]
}
]
,
stis:0,
bstiid:2189,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2189,
isDD:false
},
si2213c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2213,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2213',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2224:{
name:'',
type:612,
from:5859,
to:6084,
rp:0,
rpa:0,
mdi:'si2224c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":828,"left":819,"width":300,"height":"auto"}}',
parentGroup:'si2150',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2189',
stl:[{
stn:'Normal',
stt:0,
stsi:[2224]
}
]
,
stis:0,
bstiid:2189,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2189,
isDD:false
},
si2224c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2224,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2224',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3367:{
name:'Instructions_13',
type:612,
from:5859,
to:6084,
rp:0,
rpa:0,
mdi:'si3367c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"^^","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"4imbh","text":"Click outside of the text box here.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":35,"style":"hlnkt:wp"},{"offset":0,"length":35,"style":"textOutlineEnable:false"},{"offset":0,"length":35,"style":"opacity:1"},{"offset":0,"length":35,"style":"textShadowColor:ffffff00"},{"offset":0,"length":35,"style":"hlnke:true"},{"offset":0,"length":35,"style":"backgroundColor:unset"},{"offset":0,"length":35,"style":"textShadowX:0px"},{"offset":0,"length":35,"style":"textShadowY:0px"},{"offset":0,"length":35,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":35,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":35,"style":"textShadowBlur:0px"},{"offset":0,"length":35,"style":"textHighlightEnable:false"},{"offset":0,"length":35,"style":"textShadowEnable:false"},{"offset":0,"length":35,"style":"hlnk:"},{"offset":0,"length":35,"style":"overridden:false"},{"offset":0,"length":35,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":1125.0331491712707,"top":757.756906077348,"width":195.69051331578035},"shouldRender":true}',
parentGroup:'si2150',
retainState:false,
immo:false,
apsn:'Slide2132',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3367]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3367c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3367,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3367',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2132:{
lb:'Simulation slide 20',
id:2132,
from:13100,
to:13325,
iols:0,
i360qs:false,
sdu:7.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2132c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2158',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2242:{
ts:''
}

}

},
Slide2132c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2132,
dn:'Slide2132',
visible:'1'
},
si2275:{
name:'Simulation_20',
type:1268,
from:13326,
to:13794,
rp:0,
rpa:0,
mdi:'si2275c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2267',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2275c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2275,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2275',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2267:{
name:'Simulation_non_responsive_20',
type:1268,
from:13326,
to:13794,
rp:0,
rpa:0,
mdi:'si2267c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2275',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2286',
t:1269
}
,{
n:'si2306',
t:612
}
,{
n:'si3377',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2275',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2267c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2267,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2267',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2283,
tsp:50,
ip:'dr/02283.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2286:{
name:'Click_box_11',
type:1269,
from:6085,
to:6553,
rp:0,
rpa:0,
mdi:'si2286c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":875,"left":663.5524861878453,"width":170.7304222149085,"height":25.518722955693196},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2267',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2359);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:15.611,
lcapid:'si2306',
si:[{
n:'si2296',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2286]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2286c:{
b:[763,875,797,895],
fh:false,
fw:false,
uid:2286,
iso:false,
css:{
360:{
l:'78.498%',
t:'143.914%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'78.498%',
lhID:-1,
lvEID:0,
lvV:'143.914%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'78.498%',
t:'143.914%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'78.498%',
lhID:-1,
lvEID:0,
lvV:'143.914%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'78.498%',
t:'143.914%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'78.498%',
lhID:-1,
lvEID:0,
lvV:'143.914%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2286',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[763,875,797,895],
vb:[763,875,797,895]
},
si2296:{
name:'Shape_11',
type:612,
from:6085,
to:6553,
rp:0,
rpa:0,
mdi:'si2296c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2296]
}
]
,
stis:0,
bstiid:2286,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2286',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2296c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2296,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2296',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2306:{
name:'Rectangle_15',
type:612,
from:13326,
to:13794,
rp:0,
rpa:0,
mdi:'si2306c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":778,"width":300,"height":"auto"}}',
parentGroup:'si2267',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2317,
stt:0,
dsr:'Default_State',
stsi:[2306]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2306','si2319','si2330','si2341'],
isDD:false
},
si2306c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2306,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2306',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2319:{
name:'',
type:612,
from:6085,
to:6553,
rp:0,
rpa:0,
mdi:'si2319c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":778,"width":300,"height":"auto"}}',
parentGroup:'si2267',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2306',
stl:[{
stn:'Normal',
stt:0,
stsi:[2319]
}
]
,
stis:0,
bstiid:2306,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2306,
isDD:false
},
si2319c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2319,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2319',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2330:{
name:'',
type:612,
from:6085,
to:6553,
rp:0,
rpa:0,
mdi:'si2330c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":778,"width":300,"height":"auto"}}',
parentGroup:'si2267',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2306',
stl:[{
stn:'Normal',
stt:0,
stsi:[2330]
}
]
,
stis:0,
bstiid:2306,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2306,
isDD:false
},
si2330c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2330,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2330',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2341:{
name:'',
type:612,
from:6085,
to:6553,
rp:0,
rpa:0,
mdi:'si2341c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":935,"left":778,"width":300,"height":"auto"}}',
parentGroup:'si2267',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2306',
stl:[{
stn:'Normal',
stt:0,
stsi:[2341]
}
]
,
stis:0,
bstiid:2306,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2306,
isDD:false
},
si2341c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2341,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2341',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3377:{
name:'Instructions_14',
type:612,
from:6085,
to:6553,
rp:0,
rpa:0,
mdi:'si3377c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:15.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"^^","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"dhbg8","text":"Double-click your Instagram handle and highlight it.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":52,"style":"hlnkt:wp"},{"offset":0,"length":52,"style":"textOutlineEnable:false"},{"offset":0,"length":52,"style":"opacity:1"},{"offset":0,"length":52,"style":"textShadowColor:ffffff00"},{"offset":0,"length":52,"style":"hlnke:true"},{"offset":0,"length":52,"style":"backgroundColor:unset"},{"offset":0,"length":52,"style":"textShadowX:0px"},{"offset":0,"length":52,"style":"textShadowY:0px"},{"offset":0,"length":52,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":52,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":52,"style":"textShadowBlur:0px"},{"offset":0,"length":52,"style":"textHighlightEnable:false"},{"offset":0,"length":52,"style":"textShadowEnable:false"},{"offset":0,"length":52,"style":"hlnk:"},{"offset":0,"length":52,"style":"overridden:false"},{"offset":0,"length":52,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":594.8011049723757,"top":917.5082872928176,"width":320},"shouldRender":true}',
parentGroup:'si2267',
retainState:false,
immo:false,
apsn:'Slide2249',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3377]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3377c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3377,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3377',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2249:{
lb:'Simulation slide 21',
id:2249,
from:13326,
to:13794,
iols:0,
i360qs:false,
sdu:15.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2249c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2275',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2359:{
ts:''
}

}

},
Slide2249c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2249,
dn:'Slide2249',
visible:'1'
},
si2392:{
name:'Simulation_21',
type:1268,
from:6554,
to:6553,
rp:0,
rpa:0,
mdi:'si2392c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2366',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2384',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2392c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2392,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2392',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2384:{
name:'Simulation_non_responsive_21',
type:1268,
from:6554,
to:6553,
rp:0,
rpa:0,
mdi:'si2384c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2392',
retainState:false,
immo:false,
apsn:'Slide2366',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2392',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2384c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2384,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2384',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2400,
tsp:50,
ip:'dr/02400.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide2366:{
lb:'Simulation slide 22',
id:2366,
from:6554,
to:6595,
iols:0,
i360qs:false,
sdu:1.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2366c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2392',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2366c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2366,
dn:'Slide2366',
visible:'1'
},
si2421:{
name:'Video_2',
type:1268,
from:6596,
to:6649,
rp:0,
rpa:0,
mdi:'si2421c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide2403',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2440',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2421c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2421,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2421',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2440:{
name:'SlideVideo_2',
type:365,
from:6596,
to:6649,
rp:0,
rpa:0,
mdi:'si2440c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.8,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2421',
retainState:false,
immo:false,
apsn:'Slide2403',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si2440c:{
b:[-234,-236,1206,844],
fh:false,
fw:false,
uid:2440,
iso:false,
css:{
360:{
l:'-24.074%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-24.074%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'148.148%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-24.074%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-24.074%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'148.148%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-24.074%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-24.074%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'148.148%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2440',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/02436.png',
mp4:'vr/Vi2429.mp4',
vsf:0,
vst:1.8,
o:100,
vbwr:[-235,-237,1207,845],
vb:[-235,-237,1207,845]
},
Slide2403:{
lb:'Simulation slide 23',
id:2403,
from:6596,
to:6649,
iols:0,
i360qs:false,
sdu:1.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2403c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2421',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2403c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2403,
dn:'Slide2403',
visible:'1'
},
si2473:{
name:'Simulation_22',
type:1268,
from:13795,
to:14015,
rp:0,
rpa:0,
mdi:'si2473c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2465',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2473c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2473,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2473',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2465:{
name:'Simulation_non_responsive_22',
type:1268,
from:13795,
to:14015,
rp:0,
rpa:0,
mdi:'si2465c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2473',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2484',
t:1269
}
,{
n:'si2504',
t:612
}
,{
n:'si3387',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2473',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2465c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2465,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2465',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2481,
tsp:50,
ip:'dr/02481.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2484:{
name:'Click_box_12',
type:1269,
from:6650,
to:6870,
rp:0,
rpa:0,
mdi:'si2484c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":188.38121546961327,"left":367.9558011049723,"width":34.987728898696474,"height":31.999998988367572},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2557);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:7.34502,
lcapid:'si2504',
si:[{
n:'si2494',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2484]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2484c:{
b:[321,187,385,219],
fh:false,
fw:false,
uid:2484,
iso:false,
css:{
360:{
l:'33.025%',
t:'30.757%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'33.025%',
lhID:-1,
lvEID:0,
lvV:'30.757%',
lvID:-1,
w:'6.584%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'33.025%',
t:'30.757%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'33.025%',
lhID:-1,
lvEID:0,
lvV:'30.757%',
lvID:-1,
w:'6.584%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'33.025%',
t:'30.757%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'33.025%',
lhID:-1,
lvEID:0,
lvV:'30.757%',
lvID:-1,
w:'6.584%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2484',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[321,187,385,219],
vb:[321,187,385,219]
},
si2494:{
name:'Shape_12',
type:612,
from:6650,
to:6870,
rp:0,
rpa:0,
mdi:'si2494c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2494]
}
]
,
stis:0,
bstiid:2484,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2484',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2494c:{
b:[0,0,64,32],
fh:false,
fw:false,
uid:2494,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'6.584%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2494',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,66,34],
vb:[-2,-2,66,34]
},
si2504:{
name:'Rectangle_16',
type:612,
from:13795,
to:14015,
rp:0,
rpa:0,
mdi:'si2504c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":247,"left":336,"width":300,"height":"auto"}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2515,
stt:0,
dsr:'Default_State',
stsi:[2504]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2504','si2517','si2528','si2539'],
isDD:false
},
si2504c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2504,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2504',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2517:{
name:'',
type:612,
from:6650,
to:6870,
rp:0,
rpa:0,
mdi:'si2517c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":247,"left":336,"width":300,"height":"auto"}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2504',
stl:[{
stn:'Normal',
stt:0,
stsi:[2517]
}
]
,
stis:0,
bstiid:2504,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2504,
isDD:false
},
si2517c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2517,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2517',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2528:{
name:'',
type:612,
from:6650,
to:6870,
rp:0,
rpa:0,
mdi:'si2528c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":247,"left":336,"width":300,"height":"auto"}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2504',
stl:[{
stn:'Normal',
stt:0,
stsi:[2528]
}
]
,
stis:0,
bstiid:2504,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2504,
isDD:false
},
si2528c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2528,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2528',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2539:{
name:'',
type:612,
from:6650,
to:6870,
rp:0,
rpa:0,
mdi:'si2539c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":247,"left":336,"width":300,"height":"auto"}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2504',
stl:[{
stn:'Normal',
stt:0,
stsi:[2539]
}
]
,
stis:0,
bstiid:2504,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2504,
isDD:false
},
si2539c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2539,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2539',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3387:{
name:'Instructions_15',
type:612,
from:6650,
to:6870,
rp:0,
rpa:0,
mdi:'si3387c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"Click on the A with the color underneath it.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":44,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":44,"style":"hlnkt:wp"},{"offset":0,"length":44,"style":"textOutlineEnable:false"},{"offset":0,"length":44,"style":"opacity:1"},{"offset":0,"length":44,"style":"textShadowColor:ffffff00"},{"offset":0,"length":44,"style":"hlnke:true"},{"offset":0,"length":44,"style":"backgroundColor:unset"},{"offset":0,"length":44,"style":"textShadowX:0px"},{"offset":0,"length":44,"style":"textShadowY:0px"},{"offset":0,"length":44,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":44,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":44,"style":"textShadowBlur:0px"},{"offset":0,"length":44,"style":"textHighlightEnable:false"},{"offset":0,"length":44,"style":"textShadowEnable:false"},{"offset":0,"length":44,"style":"hlnk:"},{"offset":0,"length":44,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":286.6574585635359,"top":229.85635359116023,"width":232.98341529804037},"shouldRender":true}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide2447',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3387]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3387c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3387,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3387',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2447:{
lb:'Simulation slide 24',
id:2447,
from:13795,
to:14015,
iols:0,
i360qs:false,
sdu:7.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2447c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2473',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2557:{
ts:''
}

}

},
Slide2447c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2447,
dn:'Slide2447',
visible:'1'
},
si2590:{
name:'Simulation_23',
type:1268,
from:14016,
to:14247,
rp:0,
rpa:0,
mdi:'si2590c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2582',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2590c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2590,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2590',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2582:{
name:'Simulation_non_responsive_23',
type:1268,
from:14016,
to:14247,
rp:0,
rpa:0,
mdi:'si2582c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2590',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2601',
t:1269
}
,{
n:'si2621',
t:612
}
,{
n:'si3397',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2590',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2582c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2582,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2582',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2598,
tsp:50,
ip:'dr/02598.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2601:{
name:'Click_box_13',
type:1269,
from:6871,
to:7102,
rp:0,
rpa:0,
mdi:'si2601c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":303.71270718232046,"left":195.61878453038673,"width":49.19340860777796,"height":46.24310909713829},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2582',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2674);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:7.69602,
lcapid:'si2621',
si:[{
n:'si2611',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2601]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2601c:{
b:[212,312,246,332],
fh:false,
fw:false,
uid:2601,
iso:false,
css:{
360:{
l:'21.811%',
t:'51.316%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'21.811%',
lhID:-1,
lvEID:0,
lvV:'51.316%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'21.811%',
t:'51.316%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'21.811%',
lhID:-1,
lvEID:0,
lvV:'51.316%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'21.811%',
t:'51.316%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'21.811%',
lhID:-1,
lvEID:0,
lvV:'51.316%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2601',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[212,312,246,332],
vb:[212,312,246,332]
},
si2611:{
name:'Shape_13',
type:612,
from:6871,
to:7102,
rp:0,
rpa:0,
mdi:'si2611c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2611]
}
]
,
stis:0,
bstiid:2601,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2601',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2611c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2611,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2611',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2621:{
name:'Rectangle_17',
type:612,
from:14016,
to:14247,
rp:0,
rpa:0,
mdi:'si2621c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":372,"left":227,"width":300,"height":"auto"}}',
parentGroup:'si2582',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2632,
stt:0,
dsr:'Default_State',
stsi:[2621]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2621','si2634','si2645','si2656'],
isDD:false
},
si2621c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2621,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2621',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2634:{
name:'',
type:612,
from:6871,
to:7102,
rp:0,
rpa:0,
mdi:'si2634c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":372,"left":227,"width":300,"height":"auto"}}',
parentGroup:'si2582',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2621',
stl:[{
stn:'Normal',
stt:0,
stsi:[2634]
}
]
,
stis:0,
bstiid:2621,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2621,
isDD:false
},
si2634c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2634,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2634',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2645:{
name:'',
type:612,
from:6871,
to:7102,
rp:0,
rpa:0,
mdi:'si2645c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":372,"left":227,"width":300,"height":"auto"}}',
parentGroup:'si2582',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2621',
stl:[{
stn:'Normal',
stt:0,
stsi:[2645]
}
]
,
stis:0,
bstiid:2621,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2621,
isDD:false
},
si2645c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2645,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2645',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2656:{
name:'',
type:612,
from:6871,
to:7102,
rp:0,
rpa:0,
mdi:'si2656c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":372,"left":227,"width":300,"height":"auto"}}',
parentGroup:'si2582',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2621',
stl:[{
stn:'Normal',
stt:0,
stsi:[2656]
}
]
,
stis:0,
bstiid:2621,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2621,
isDD:false
},
si2656c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2656,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2656',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3397:{
name:'Instructions_16',
type:612,
from:6871,
to:7102,
rp:0,
rpa:0,
mdi:'si3397c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"<<","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"1s5b4","text":"Click on the white box under document colors","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":44,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":44,"style":"hlnkt:wp"},{"offset":0,"length":44,"style":"textOutlineEnable:false"},{"offset":0,"length":44,"style":"opacity:1"},{"offset":0,"length":44,"style":"textShadowColor:ffffff00"},{"offset":0,"length":44,"style":"hlnke:true"},{"offset":0,"length":44,"style":"backgroundColor:unset"},{"offset":0,"length":44,"style":"textShadowX:0px"},{"offset":0,"length":44,"style":"textShadowY:0px"},{"offset":0,"length":44,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":44,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":44,"style":"textShadowBlur:0px"},{"offset":0,"length":44,"style":"textHighlightEnable:false"},{"offset":0,"length":44,"style":"textShadowEnable:false"},{"offset":0,"length":44,"style":"hlnk:"},{"offset":0,"length":44,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":267.5524861878453,"top":282.5193370165746,"width":239.8894504947557},"shouldRender":true}',
parentGroup:'si2582',
retainState:false,
immo:false,
apsn:'Slide2564',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3397]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3397c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3397,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3397',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2564:{
lb:'Simulation slide 25',
id:2564,
from:14016,
to:14247,
iols:0,
i360qs:false,
sdu:7.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2564c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2590',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2674:{
ts:''
}

}

},
Slide2564c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2564,
dn:'Slide2564',
visible:'1'
},
si2707:{
name:'Simulation_24',
type:1268,
from:14248,
to:14493,
rp:0,
rpa:0,
mdi:'si2707c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2699',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2707c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2707,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2707',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2699:{
name:'Simulation_non_responsive_24',
type:1268,
from:14248,
to:14493,
rp:0,
rpa:0,
mdi:'si2699c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2707',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2718',
t:1269
}
,{
n:'si2738',
t:612
}
,{
n:'si3407',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":true,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2707',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2699c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2699,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2699',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2715,
tsp:50,
ip:'dr/02715.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2718:{
name:'Click_box_14',
type:1269,
from:7103,
to:7348,
rp:0,
rpa:0,
mdi:'si2718c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":543.4364640883978,"left":448.23756906077347,"width":146.85083884560598,"height":113.67958026696304},"attempts":1024,"showHandCursorOnClickableAreas":true}',
parentGroup:'si2699',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2791);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:8.16602,
lcapid:'si2738',
si:[{
n:'si2728',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2718]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2718c:{
b:[451,502,631,548],
fh:false,
fw:false,
uid:2718,
iso:false,
css:{
360:{
l:'46.399%',
t:'82.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'46.399%',
lhID:-1,
lvEID:0,
lvV:'82.566%',
lvID:-1,
w:'18.519%',
h:'7.566%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'46.399%',
t:'82.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'46.399%',
lhID:-1,
lvEID:0,
lvV:'82.566%',
lvID:-1,
w:'18.519%',
h:'7.566%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'46.399%',
t:'82.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'46.399%',
lhID:-1,
lvEID:0,
lvV:'82.566%',
lvID:-1,
w:'18.519%',
h:'7.566%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2718',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[451,502,631,548],
vb:[451,502,631,548]
},
si2728:{
name:'Shape_14',
type:612,
from:7103,
to:7348,
rp:0,
rpa:0,
mdi:'si2728c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2728]
}
]
,
stis:0,
bstiid:2718,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2718',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2728c:{
b:[0,0,180,46],
fh:false,
fw:false,
uid:2728,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'7.566%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'7.566%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'7.566%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2728',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,182,48],
vb:[-2,-2,182,48]
},
si2738:{
name:'Rectangle_18',
type:612,
from:14248,
to:14493,
rp:0,
rpa:0,
mdi:'si2738c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":466,"width":300,"height":"auto"}}',
parentGroup:'si2699',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2749,
stt:0,
dsr:'Default_State',
stsi:[2738]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2738','si2751','si2762','si2773'],
isDD:false
},
si2738c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2738,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2738',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2751:{
name:'',
type:612,
from:7103,
to:7348,
rp:0,
rpa:0,
mdi:'si2751c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":466,"width":300,"height":"auto"}}',
parentGroup:'si2699',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2738',
stl:[{
stn:'Normal',
stt:0,
stsi:[2751]
}
]
,
stis:0,
bstiid:2738,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2738,
isDD:false
},
si2751c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2751,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2751',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2762:{
name:'',
type:612,
from:7103,
to:7348,
rp:0,
rpa:0,
mdi:'si2762c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":466,"width":300,"height":"auto"}}',
parentGroup:'si2699',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2738',
stl:[{
stn:'Normal',
stt:0,
stsi:[2762]
}
]
,
stis:0,
bstiid:2738,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2738,
isDD:false
},
si2762c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2762,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2762',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2773:{
name:'',
type:612,
from:7103,
to:7348,
rp:0,
rpa:0,
mdi:'si2773c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":466,"width":300,"height":"auto"}}',
parentGroup:'si2699',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2738',
stl:[{
stn:'Normal',
stt:0,
stsi:[2773]
}
]
,
stis:0,
bstiid:2738,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2738,
isDD:false
},
si2773c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2773,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2773',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si3407:{
name:'Instructions_17',
type:612,
from:7103,
to:7348,
rp:0,
rpa:0,
mdi:'si3407c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"textPresetId":"text-comment-box","editorState":{"blocks":[{"key":"3tirc","text":"^^","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"textShadowColor:ffffff00"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"textShadowX:0px"},{"offset":0,"length":2,"style":"textShadowY:0px"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":2,"style":"textShadowBlur:0px"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"dk7lt","text":"Click out of the document colors area.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"textOutlineEnable:false"},{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"textShadowColor:ffffff00"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"textShadowX:0px"},{"offset":0,"length":38,"style":"textShadowY:0px"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":38,"style":"textShadowBlur:0px"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-comment-box"}}],"entityMap":{}},"overriddenProperties":[60004]},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"left":440.23756906077347,"top":664.6187845303867,"width":227.4513033872151},"shouldRender":true}',
parentGroup:'si2699',
retainState:false,
immo:false,
apsn:'Slide2681',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'',
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3407]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3407c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3407,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3407',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:-1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide2681:{
lb:'Simulation slide 26',
id:2681,
from:14248,
to:14493,
iols:0,
i360qs:false,
sdu:8.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2681c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2707',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2791:{
ts:''
}

}

},
Slide2681c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2681,
dn:'Slide2681',
visible:'1'
},
si2824:{
name:'Simulation_25',
type:1268,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2824c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2816',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2824c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2824,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2824',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2816:{
name:'Simulation_non_responsive_25',
type:1268,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2816c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2824',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2835',
t:1269
}
,{
n:'si2855',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":1,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2824',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2816c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2816,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2816',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2832,
tsp:50,
ip:'dr/02832.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2835:{
name:'Click_box_15',
type:1269,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2835c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":596,"left":345,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2816',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2908);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:1.85601,
lcapid:'si2855',
si:[{
n:'si2845',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2835]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2835c:{
b:[345,596,379,616],
fh:false,
fw:false,
uid:2835,
iso:false,
css:{
360:{
l:'35.494%',
t:'98.026%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'35.494%',
lhID:-1,
lvEID:0,
lvV:'98.026%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'35.494%',
t:'98.026%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'35.494%',
lhID:-1,
lvEID:0,
lvV:'98.026%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'35.494%',
t:'98.026%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'35.494%',
lhID:-1,
lvEID:0,
lvV:'98.026%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2835',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[345,596,379,616],
vb:[345,596,379,616]
},
si2845:{
name:'Shape_15',
type:612,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2845c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2845]
}
]
,
stis:0,
bstiid:2835,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2835',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2845c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2845,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2845',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2855:{
name:'Rectangle_19',
type:612,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2855c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":656,"left":360,"width":300,"height":"auto"}}',
parentGroup:'si2816',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2866,
stt:0,
dsr:'Default_State',
stsi:[2855]
}
,{
stn:2878,
stt:102,
dsr:'Failure',
stsi:[2879]
}
,{
stn:2889,
stt:103,
dsr:'Hint',
stsi:[2890]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2855','si2868','si2879','si2890'],
isDD:false
},
si2855c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2855,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2855',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2868:{
name:'',
type:612,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2868c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":656,"left":360,"width":300,"height":"auto"}}',
parentGroup:'si2816',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2855',
stl:[{
stn:'Normal',
stt:0,
stsi:[2868]
}
]
,
stis:0,
bstiid:2855,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2855,
isDD:false
},
si2868c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2868,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2868',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2879:{
name:'',
type:612,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2879c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":656,"left":360,"width":300,"height":"auto"}}',
parentGroup:'si2816',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2855',
stl:[{
stn:'Normal',
stt:0,
stsi:[2879]
}
]
,
stis:0,
bstiid:2855,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2855,
isDD:false
},
si2879c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2879,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2879',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2890:{
name:'',
type:612,
from:7349,
to:7404,
rp:0,
rpa:0,
mdi:'si2890c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":656,"left":360,"width":300,"height":"auto"}}',
parentGroup:'si2816',
retainState:false,
immo:false,
apsn:'Slide2798',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2855',
stl:[{
stn:'Normal',
stt:0,
stsi:[2890]
}
]
,
stis:0,
bstiid:2855,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2855,
isDD:false
},
si2890c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2890,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2890',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2798:{
lb:'Simulation slide 27',
id:2798,
from:7349,
to:7404,
iols:0,
i360qs:false,
sdu:1.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2798c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2824',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2908:{
ts:''
}

}

},
Slide2798c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2798,
dn:'Slide2798',
visible:'1'
},
si2941:{
name:'Simulation_26',
type:1268,
from:7405,
to:7404,
rp:0,
rpa:0,
mdi:'si2941c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2915',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2933',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2941c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2941,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2941',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2933:{
name:'Simulation_non_responsive_26',
type:1268,
from:7405,
to:7404,
rp:0,
rpa:0,
mdi:'si2933c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2941',
retainState:false,
immo:false,
apsn:'Slide2915',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2941',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2933c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2933,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2933',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2949,
tsp:50,
ip:'dr/02949.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide2915:{
lb:'Simulation slide 28',
id:2915,
from:7405,
to:7785,
iols:0,
i360qs:false,
sdu:12.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2915c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2941',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2915c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2915,
dn:'Slide2915',
visible:'1'
},
StAd29:{
from:14674,
to:21956,
src:'ar/StAd28.mp3',
du:243400,
saup:[{
sn:622,
del:0,
du:21.7,
l:false
}
,{
sn:739,
del:0,
du:22.7,
l:false
}
,{
sn:856,
del:0,
du:13.2,
l:false
}
,{
sn:973,
del:0,
du:6.9,
l:false
}
,{
sn:1010,
del:0,
du:5,
l:false
}
,{
sn:1047,
del:0,
du:18.6,
l:false
}
,{
sn:1164,
del:0,
du:8.2,
l:false
}
,{
sn:1201,
del:0,
du:1.6,
l:false
}
,{
sn:1316,
del:0,
du:17.8,
l:false
}
,{
sn:1433,
del:0,
du:5.1,
l:false
}
,{
sn:1548,
del:0,
du:20.4,
l:false
}
,{
sn:1665,
del:0,
du:1,
l:false
}
,{
sn:1783,
del:0,
du:5.7,
l:false
}
,{
sn:1900,
del:0,
du:19.1,
l:false
}
,{
sn:2017,
del:0,
du:12.2,
l:false
}
,{
sn:2132,
del:0,
du:7.5,
l:false
}
,{
sn:2249,
del:0,
du:15.6,
l:false
}
,{
sn:2366,
del:0,
du:1.4,
l:false
}
,{
sn:2403,
del:0,
du:1.8,
l:false
}
,{
sn:2447,
del:0,
du:7.4,
l:false
}
,{
sn:2564,
del:0,
du:7.7,
l:false
}
,{
sn:2681,
del:0,
du:8.2,
l:false
}
,{
sn:2798,
del:0,
du:1.9,
l:false
}
,{
sn:2915,
del:0,
du:12.7,
l:false
}
]

},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
var572var572:{
vid:572,
name:'variableEditBoxStr_1',
vv:'',
vvt:2,
vt:0
},
var573var573:{
vid:573,
name:'variableEditBoxNum_1',
vv:0,
vvt:1,
vt:0
},
var1266var1266:{
vid:1266,
name:'variableEditBoxStr_2',
vv:'',
vvt:2,
vt:0
},
var1267var1267:{
vid:1267,
name:'variableEditBoxNum_2',
vv:0,
vvt:1,
vt:0
},
var1498var1498:{
vid:1498,
name:'variableEditBoxStr_3',
vv:'',
vvt:2,
vt:0
},
var1499var1499:{
vid:1499,
name:'variableEditBoxNum_3',
vv:0,
vvt:1,
vt:0
},
var2082var2082:{
vid:2082,
name:'variableEditBoxStr_4',
vv:'',
vvt:2,
vt:0
},
var2083var2083:{
vid:2083,
name:'variableEditBoxNum_4',
vv:0,
vvt:1,
vt:0
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned',
var572:'variableEditBoxStr_1',
var573:'variableEditBoxNum_1',
var1266:'variableEditBoxStr_2',
var1267:'variableEditBoxNum_2',
var1498:'variableEditBoxStr_3',
var1499:'variableEditBoxNum_3',
var2082:'variableEditBoxStr_4',
var2083:'variableEditBoxNum_4'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1440,
h:1080,
iw:1440,
ih:1080,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'Lab 2 Software Simulation.cpt'
},
projectThemeData:{
image_presets:'{\\
  "theme_image_default": {\\
    "meta": {\\
      "name": "kCPImageStyleNormal",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_default--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_default--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Normal",\\
        "mixBlendMode": "normal"\\
      }\\
    }\\
  },\\
\\
  "theme_image_greyscale": {\\
    "meta": {\\
      "name": "kCPImageStyleGreyscale",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_greyscale--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Greyscale",\\
        "mixBlendMode": "saturation",\\
        "intensity": "var(--theme_image_greyscale--intensity)",\\
        "filterColor": {\\
          "fill": "#000000",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_lighten": {\\
    "meta": {\\
      "name": "kCPImageStyleLighten",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_lighten--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_lighten--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Lighten",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_lighten--intensity)",\\
        "filterColor": {\\
          "fill": "#FFFFFF",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_darken": {\\
    "meta": {\\
      "name": "kCPImageStyleDarken",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_darken--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_darken--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Darken",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_darken--intensity)",\\
        "filterColor": {\\
          "fill": "var(--black)",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_overlay": {\\
    "meta": {\\
      "name": "kCPImageStyleOverlay",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_overlay--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_overlay--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Overlay",\\
        "mixBlendMode": "overlay",\\
        "intensity": "var(--theme_image_overlay--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_colorize": {\\
    "meta": {\\
      "name": "kCPImageStyleColorize",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_colorize--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_colorize--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Colorize",\\
        "mixBlendMode": "color",\\
        "intensity": "var(--theme_image_colorize--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  }\\
}\\
',
meta:'{\\
  "name": "kCPThemeLight",\\
  "description": "kCPThemeLightDescription",\\
  "version": 0.1,\\
  "guid": "Default-Light-Theme",\\
  "default_presets": {\\
    "0": "cp_default_shape_solid_style",\\
    "1": "text-body-1",\\
    "2": "theme_image_default",\\
    "3": "cp_default_slide_style",\\
    "4": "cp_textinshape_body_1",\\
    "5": "cp_default_line_shape_style",\\
    "6": "cp_default_complex_shape_solid_style",\\
    "7": "cp_button_style_1_textonly",\\
    "8": "cp_checkbox_style_1_textonly",\\
    "9": "cp_svg_style",\\
    "10": "cp_dropDown_style_1",\\
    "11": "cp_radiobutton_style_1_textonly",\\
    "12": "cp_inputField_style_1",\\
    "13": "cp_clickbox_style",\\
    "14": "cp_responsive_container_style",\\
    "15": "cp_default_shape_solid_style"\\
  },\\
  "color_palettes": [\\
    {\\
      "name": "Light Palette - 1",\\
      "colors": [\\
        "var(--color1)",\\
        "var(--color2)",\\
        "var(--color3)",\\
        "var(--color4)",\\
        "var(--color5)",\\
        "var(--color6)",\\
        "var(--color7)",\\
        "var(--color5_light)",\\
        "var(--color4_dark)"\\
      ]\\
    }\\
  ],\\
  "active_color_palette": 0\\
}',
other_presets:'{\\
  "cp_default_slide_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "type": 3,\\
      "category": 0\\
    },\\
    "backgroundColor": "var(--palette-color1)",\\
    "outlineColor": "var(--palette-color5)",\\
    "outlineWidth": 1,\\
    "outlineStyle": "solid",\\
    "outlineCap": "butt",\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 0,\\
            "y": 0\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_responsive_container_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 14,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": 1,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_correct": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--success)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incorrect": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--error)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incomplete": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--incomplete)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_hint": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--hint)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_retry": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--retry)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_timeout": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--timeout)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color1)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_radial_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}',
theme:'{\\
  "--primary": "#F1EEE6",\\
\\
  "--color1": "#FFFFFF",\\
  "--color2": "#F8F7F4",\\
  "--color3": "#F1EEE6",\\
  "--color4": "#D6D5D1",\\
  "--color5": "#666666",\\
  "--color6": "#333333",\\
  "--color7": "#020C1C",\\
  "--colorC7": "#F7F7F7",\\
  "--disabledC12": "#989898",\\
  "--color1_light": "#FFCD74",\\
  "--color1_dark": "#C76D12",\\
  "--color2_light": "#86FFFF",\\
  "--color2_dark": "#00ACCC",\\
  "--color3_light": "#9B5DFF",\\
  "--color3_dark": "#0000CA",\\
  "--color4_light": "#99FF99",\\
  "--color4_dark": "#112FA7",\\
  "--color5_light": "#163EE5",\\
  "--color5_dark": "#00CB92",\\
  "--color6_light": "#7697FF",\\
  "--color6_dark": "#0040CB",\\
  "--color7_light": "#FF8E64",\\
  "--color7_dark": "#C5230B",\\
\\
  "--success": "#558564",\\
  "--error": "#C83E4D",\\
  "--hint": "#CB6F10",\\
  "--incomplete":"#E8BD2B",\\
  "--timeout": "#C74545",\\
  "--retry": "#CB6F10",\\
  "--white": "#ffffff",\\
  "--black": "#000000",\\
\\
  "--greyscale1": "#FFFFFF",\\
  "--greyscale2": "#F1EEE61F",\\
  "--greyscale3": "#B3B3B3",\\
  "--greyscale4": "#4B4B4B",\\
  "--greyscale5": "#333333",\\
  "--disabled": "#818181",\\
\\
  "--palette-color0": "var(--color1)",\\
  "--palette-color1": "var(--color2)",\\
  "--palette-color2": "var(--color3)",\\
  "--palette-color3": "var(--color4)",\\
  "--palette-color4": "var(--color5)",\\
  "--palette-color5": "var(--color6)",\\
  "--palette-color6": "var(--color7)",\\
  "--palette-color7": "var(--color5_light)",\\
  "--palette-color8": "var(--color4_dark)",\\
\\
  "--design-option-color1": "255, 255, 255",\\
  "--design-option-color2": "248, 247, 244",\\
  "--design-option-color3": "241, 238, 230",\\
  "--design-option-color4": "214, 213, 209",\\
  "--design-option-color5": "102, 102, 102",\\
  "--design-option-color6": "51, 51, 51",\\
  "--design-option-color7": "2, 12, 28",\\
  "--design-option-color5_light": "22, 62, 229",\\
  "--design-option-color4_dark": "17, 47, 167",\\
\\
  "--c1": "var(--design-option-color1)",\\
  "--c2": "var(--design-option-color2)",\\
  "--c3": "var(--design-option-color3)",\\
  "--c4": "var(--design-option-color4)",\\
  "--c5": "var(--design-option-color5)",\\
  "--c6": "var(--design-option-color6)",\\
  "--c7": "var(--design-option-color7)",\\
  "--c8": "var(--design-option-color5_light)",\\
  "--c9": "var(--design-option-color4_dark)",\\
  \\
  "--widget-container--fillcolor": "var(--palette-color1)",\\
\\
  "--font1": "Georgia",\\
  "--font2": "Arial",\\
  "--text-style-unset": "none",\\
\\
  "--text-heading-1--fontSize--desktop": "120px",\\
  "--text-heading-1--fontSize--tablet": "100px",\\
  "--text-heading-1--fontSize--mobile": "80px",\\
  "--text-heading-1--fontFamily": "var(--font1)",\\
  "--text-heading-1--fontWeight": "normal",\\
  "--text-heading-1--fontType": "regular",\\
  "--text-heading-1--fontStyle": "normal",\\
  "--text-heading-1--fontStretch": "normal",\\
  "--text-heading-1--lineHeight": "1.07",\\
  "--text-heading-1--marginLeft": "0px",\\
  "--text-heading-1--color": "var(--palette-color6)",\\
  "--text-heading-1--borderBottomStyle": "none",\\
  "--text-heading-1--textDecoration": "none",\\
  "--text-heading-1--letterSpacing": "-0.01",\\
  "--text-heading-1--textTransform": "none",\\
  "--text-heading-1--stroke": "var(--palette-color2)",\\
  "--text-heading-1--textAlign": "left",\\
  "--text-heading-1--justifyContent": "flex-start",\\
  "--text-heading-1--marginTop": "auto",\\
  "--text-heading-1--marginBottom": "0",\\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-2--fontSize--desktop": "80px",\\
  "--text-heading-2--fontSize--tablet": "72px",\\
  "--text-heading-2--fontSize--mobile": "60px",\\
  "--text-heading-2--fontFamily": "var(--font1)",\\
  "--text-heading-2--fontWeight": "normal",\\
  "--text-heading-2--fontType": "regular",\\
  "--text-heading-2--fontStyle": "normal",\\
  "--text-heading-2--fontStretch": "normal",\\
  "--text-heading-2--lineHeight": "1.1",\\
  "--text-heading-2--marginLeft": "0px",\\
  "--text-heading-2--color": "var(--palette-color6)",\\
  "--text-heading-2--borderBottomStyle": "none",\\
  "--text-heading-2--textDecoration": "none",\\
  "--text-heading-2--letterSpacing": "-0.04",\\
  "--text-heading-2--textTransform": "none",\\
  "--text-heading-2--stroke": "var(--palette-color2)",\\
  "--text-heading-2--textAlign": "left",\\
  "--text-heading-2--justifyContent": "flex-start",\\
  "--text-heading-2--marginTop": "auto",\\
  "--text-heading-2--marginBottom": "0",\\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-3--fontSize--desktop": "60px",\\
  "--text-heading-3--fontSize--tablet": "52px",\\
  "--text-heading-3--fontSize--mobile": "44px",\\
  "--text-heading-3--fontFamily": "var(--font1)",\\
  "--text-heading-3--fontWeight": "normal",\\
  "--text-heading-3--fontType": "regular",\\
  "--text-heading-3--fontStyle": "normal",\\
  "--text-heading-3--fontStretch": "normal",\\
  "--text-heading-3--lineHeight": "1.1",\\
  "--text-heading-3--marginLeft": "0px",\\
  "--text-heading-3--color": "var(--palette-color6)",\\
  "--text-heading-3--borderBottomStyle": "none",\\
  "--text-heading-3--textDecoration": "none",\\
  "--text-heading-3--letterSpacing": "0.03",\\
  "--text-heading-3--textTransform": "none",\\
  "--text-heading-3--stroke": "var(--palette-color2)",\\
  "--text-heading-3--textAlign": "left",\\
  "--text-heading-3--justifyContent": "flex-start",\\
  "--text-heading-3--marginTop": "auto",\\
  "--text-heading-3--marginBottom": "0",\\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-4--fontSize--desktop": "52px",\\
  "--text-heading-4--fontSize--tablet": "40px",\\
  "--text-heading-4--fontSize--mobile": "32px",\\
  "--text-heading-4--fontFamily": "var(--font1)",\\
  "--text-heading-4--fontWeight": "normal",\\
  "--text-heading-4--fontType": "regular",\\
  "--text-heading-4--fontStyle": "normal",\\
  "--text-heading-4--fontStretch": "normal",\\
  "--text-heading-4--lineHeight": "1.15",\\
  "--text-heading-4--marginLeft": "0px",\\
  "--text-heading-4--color": "var(--palette-color6)",\\
  "--text-heading-4--borderBottomStyle": "none",\\
  "--text-heading-4--textDecoration": "none",\\
  "--text-heading-4--letterSpacing": "0.10",\\
  "--text-heading-4--textTransform": "uppercase",\\
  "--text-heading-4--stroke": "var(--palette-color2)",\\
  "--text-heading-4--textAlign": "left",\\
  "--text-heading-4--justifyContent": "flex-start",\\
  "--text-heading-4--marginTop": "auto",\\
  "--text-heading-4--marginBottom": "0",\\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-5--fontSize--desktop": "40px",\\
  "--text-heading-5--fontSize--tablet": "32px",\\
  "--text-heading-5--fontSize--mobile": "28px",\\
  "--text-heading-5--fontFamily": "var(--font1)",\\
  "--text-heading-5--fontWeight": "normal",\\
  "--text-heading-5--fontType": "regular",\\
  "--text-heading-5--fontStyle": "normal",\\
  "--text-heading-5--fontStretch": "normal",\\
  "--text-heading-5--lineHeight": "1.2",\\
  "--text-heading-5--marginLeft": "0px",\\
  "--text-heading-5--color": "var(--palette-color6)",\\
  "--text-heading-5--borderBottomStyle": "none",\\
  "--text-heading-5--textDecoration": "none",\\
  "--text-heading-5--letterSpacing": "0",\\
  "--text-heading-5--textTransform": "none",\\
  "--text-heading-5--stroke": "var(--palette-color2)",\\
  "--text-heading-5--textAlign": "left",\\
  "--text-heading-5--justifyContent": "flex-start",\\
  "--text-heading-5--marginTop": "auto",\\
  "--text-heading-5--marginBottom": "0",\\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-6--fontSize--desktop": "36px",\\
  "--text-heading-6--fontSize--tablet": "28px",\\
  "--text-heading-6--fontSize--mobile": "24px",\\
  "--text-heading-6--fontFamily": "var(--font2)",\\
  "--text-heading-6--fontWeight": "normal",\\
  "--text-heading-6--fontType": "regular",\\
  "--text-heading-6--fontStyle": "normal",\\
  "--text-heading-6--fontStretch": "normal",\\
  "--text-heading-6--lineHeight": "1.2",\\
  "--text-heading-6--marginLeft": "0px",\\
  "--text-heading-6--color": "var(--palette-color6)",\\
  "--text-heading-6--borderBottomStyle": "none",\\
  "--text-heading-6--textDecoration": "none",\\
  "--text-heading-6--letterSpacing": "0",\\
  "--text-heading-6--textTransform": "none",\\
  "--text-heading-6--stroke": "var(--palette-color2)",\\
  "--text-heading-6--textAlign": "left",\\
  "--text-heading-6--justifyContent": "flex-start",\\
  "--text-heading-6--marginTop": "auto",\\
  "--text-heading-6--marginBottom": "0",\\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-7--fontSize--desktop": "20px",\\
  "--text-heading-7--fontSize--tablet": "20px",\\
  "--text-heading-7--fontSize--mobile": "20px",\\
  "--text-heading-7--fontFamily": "var(--font1)",\\
  "--text-heading-7--fontWeight": "normal",\\
  "--text-heading-7--fontType": "regular",\\
  "--text-heading-7--fontStyle": "normal",\\
  "--text-heading-7--fontStretch": "normal",\\
  "--text-heading-7--lineHeight": "1.35",\\
  "--text-heading-7--marginLeft": "0px",\\
  "--text-heading-7--color": "var(--palette-color5)",\\
  "--text-heading-7--borderBottomStyle": "none",\\
  "--text-heading-7--textDecoration": "none",\\
  "--text-heading-7--letterSpacing": "0",\\
  "--text-heading-7--textTransform": "none",\\
  "--text-heading-7--stroke": "var(--palette-color2)",\\
  "--text-heading-7--textAlign": "left",\\
  "--text-heading-7--justifyContent": "flex-start",\\
  "--text-heading-7--marginTop": "auto",\\
  "--text-heading-7--marginBottom": "0",\\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-8--fontSize--desktop": "72px",\\
  "--text-heading-8--fontSize--tablet": "48px",\\
  "--text-heading-8--fontSize--mobile": "32px",\\
  "--text-heading-8--fontFamily": "var(--font1)",\\
  "--text-heading-8--fontWeight": "normal",\\
  "--text-heading-8--fontType": "regular",\\
  "--text-heading-8--fontStyle": "normal",\\
  "--text-heading-8--fontStretch": "normal",\\
  "--text-heading-8--lineHeight": "1.35",\\
  "--text-heading-8--marginLeft": "0px",\\
  "--text-heading-8--color": "var(--palette-color5)",\\
  "--text-heading-8--borderBottomStyle": "none",\\
  "--text-heading-8--textDecoration": "none",\\
  "--text-heading-8--letterSpacing": "0",\\
  "--text-heading-8--textTransform": "none",\\
  "--text-heading-8--stroke": "var(--palette-color2)",\\
  "--text-heading-8--textAlign": "center",\\
  "--text-heading-8--justifyContent": "flex-start",\\
  "--text-heading-8--marginTop": "auto",\\
  "--text-heading-8--marginBottom": "0",\\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-9--fontSize--desktop": "32px",\\
  "--text-heading-9--fontSize--tablet": "32px",\\
  "--text-heading-9--fontSize--mobile": "32px",\\
  "--text-heading-9--fontFamily": "var(--font1)",\\
  "--text-heading-9--fontWeight": "normal",\\
  "--text-heading-9--fontType": "regular",\\
  "--text-heading-9--fontStyle": "normal",\\
  "--text-heading-9--fontStretch": "normal",\\
  "--text-heading-9--lineHeight": "1.35",\\
  "--text-heading-9--marginLeft": "0px",\\
  "--text-heading-9--color": "var(--palette-color5)",\\
  "--text-heading-9--borderBottomStyle": "none",\\
  "--text-heading-9--textDecoration": "none",\\
  "--text-heading-9--letterSpacing": "0",\\
  "--text-heading-9--textTransform": "none",\\
  "--text-heading-9--stroke": "var(--palette-color2)",\\
  "--text-heading-9--textAlign": "center",\\
  "--text-heading-9--justifyContent": "flex-start",\\
  "--text-heading-9--marginTop": "auto",\\
  "--text-heading-9--marginBottom": "0",\\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-1--fontSize--desktop": "22px",\\
  "--text-body-1--fontSize--tablet": "20px",\\
  "--text-body-1--fontSize--mobile": "18px",\\
  "--text-body-1--fontFamily": "var(--font1)",\\
  "--text-body-1--fontWeight": "normal",\\
  "--text-body-1--fontType": "regular",\\
  "--text-body-1--fontStyle": "normal",\\
  "--text-body-1--fontStretch": "normal",\\
  "--text-body-1--lineHeight": "1.3",\\
  "--text-body-1--marginLeft": "0px",\\
  "--text-body-1--color": "var(--palette-color5)",\\
  "--text-body-1--borderBottomStyle": "none",\\
  "--text-body-1--textDecoration": "none",\\
  "--text-body-1--letterSpacing": "0",\\
  "--text-body-1--textTransform": "none",\\
  "--text-body-1--stroke": "var(--palette-color2)",\\
  "--text-body-1--textAlign": "left",\\
  "--text-body-1--justifyContent": "flex-start",\\
  "--text-body-1--marginTop": "auto",\\
  "--text-body-1--marginBottom": "0",\\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-2--fontSize--desktop": "22px",\\
  "--text-body-2--fontSize--tablet": "20px",\\
  "--text-body-2--fontSize--mobile": "18px",\\
  "--text-body-2--fontFamily": "var(--font2)",\\
  "--text-body-2--fontWeight": "normal",\\
  "--text-body-2--fontType": "regular",\\
  "--text-body-2--fontStyle": "normal",\\
  "--text-body-2--fontStretch": "normal",\\
  "--text-body-2--lineHeight": "1.3",\\
  "--text-body-2--marginLeft": "0px",\\
  "--text-body-2--color": "var(--palette-color4)",\\
  "--text-body-2--borderBottomStyle": "none",\\
  "--text-body-2--textDecoration": "none",\\
  "--text-body-2--letterSpacing": "0.03",\\
  "--text-body-2--textTransform": "none",\\
  "--text-body-2--Stroke": "var(--palette-color2)",\\
  "--text-body-2--textAlign": "left",\\
  "--text-body-2--justifyContent": "flex-start",\\
  "--text-body-2--marginTop": "auto",\\
  "--text-body-2--marginBottom": "0",\\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-3--fontSize--desktop": "18px",\\
  "--text-body-3--fontSize--tablet": "16px",\\
  "--text-body-3--fontSize--mobile": "16px",\\
  "--text-body-3--fontFamily": "var(--font1)",\\
  "--text-body-3--fontWeight": "normal",\\
  "--text-body-3--fontType": "regular",\\
  "--text-body-3--fontStyle": "normal",\\
  "--text-body-3--fontStretch": "normal",\\
  "--text-body-3--lineHeight": "1.35",\\
  "--text-body-3--marginLeft": "0px",\\
  "--text-body-3--color": "var(--palette-color4)",\\
  "--text-body-3--borderBottomStyle": "none",\\
  "--text-body-3--textDecoration": "none",\\
  "--text-body-3--letterSpacing": "0",\\
  "--text-body-3--textTransform": "none",\\
  "--text-body-3--Stroke": "var(--palette-color2)",\\
  "--text-body-3--textAlign": "left",\\
  "--text-body-3--justifyContent": "flex-start",\\
  "--text-body-3--marginTop": "auto",\\
  "--text-body-3--marginBottom": "0",\\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-4--fontSize--desktop": "18px",\\
  "--text-body-4--fontSize--tablet": "16px",\\
  "--text-body-4--fontSize--mobile": "16px",\\
  "--text-body-4--fontFamily": "var(--font2)",\\
  "--text-body-4--fontWeight": "normal",\\
  "--text-body-4--fontType": "regular",\\
  "--text-body-4--fontStyle": "normal",\\
  "--text-body-4--fontStretch": "normal",\\
  "--text-body-4--lineHeight": "1.35",\\
  "--text-body-4--marginLeft": "0px",\\
  "--text-body-4--color": "var(--palette-color4)",\\
  "--text-body-4--borderBottomStyle": "none",\\
  "--text-body-4--textDecoration": "none",\\
  "--text-body-4--letterSpacing": "0",\\
  "--text-body-4--textTransform": "none",\\
  "--text-body-4--Stroke": "var(--palette-color2)",\\
  "--text-body-4--textAlign": "left",\\
  "--text-body-4--justifyContent": "flex-start",\\
  "--text-body-4--marginTop": "auto",\\
  "--text-body-4--marginBottom": "0",\\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-5--fontSize--desktop": "18px",\\
  "--text-body-5--fontSize--tablet": "16px",\\
  "--text-body-5--fontSize--mobile": "16px",\\
  "--text-body-5--fontFamily": "var(--font1)",\\
  "--text-body-5--fontWeight": "normal",\\
  "--text-body-5--fontType": "italic",\\
  "--text-body-5--fontStyle": "normal",\\
  "--text-body-5--fontStretch": "normal",\\
  "--text-body-5--lineHeight": "1.35",\\
  "--text-body-5--marginLeft": "0px",\\
  "--text-body-5--color": "var(--palette-color4)",\\
  "--text-body-5--borderBottomStyle": "none",\\
  "--text-body-5--textDecoration": "none",\\
  "--text-body-5--letterSpacing": "0",\\
  "--text-body-5--textTransform": "none",\\
  "--text-body-5--Stroke": "var(--palette-color2)",\\
  "--text-body-5--textAlign": "center",\\
  "--text-body-5--justifyContent": "flex-start",\\
  "--text-body-5--marginTop": "auto",\\
  "--text-body-5--marginBottom": "0",\\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-6--fontSize--desktop": "16px",\\
  "--text-body-6--fontSize--tablet": "14px",\\
  "--text-body-6--fontSize--mobile": "14px",\\
  "--text-body-6--fontFamily": "var(--font2)",\\
  "--text-body-6--fontWeight": "normal",\\
  "--text-body-6--fontType": "regular",\\
  "--text-body-6--fontStyle": "normal",\\
  "--text-body-6--fontStretch": "normal",\\
  "--text-body-6--lineHeight": "1.35",\\
  "--text-body-6--marginLeft": "0px",\\
  "--text-body-6--color": "var(--palette-color4)",\\
  "--text-body-6--borderBottomStyle": "none",\\
  "--text-body-6--textDecoration": "none",\\
  "--text-body-6--letterSpacing": "0",\\
  "--text-body-6--textTransform": "none",\\
  "--text-body-6--Stroke": "var(--palette-color2)",\\
  "--text-body-6--textAlign": "left",\\
  "--text-body-6--justifyContent": "flex-start",\\
  "--text-body-6--marginTop": "auto",\\
  "--text-body-6--marginBottom": "0",\\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-1--fontSize--desktop": "22px",\\
  "--text-component-1--fontSize--tablet": "20px",\\
  "--text-component-1--fontSize--mobile": "20px",\\
  "--text-component-1--fontFamily": "var(--font1)",\\
  "--text-component-1--fontWeight": "normal",\\
  "--text-component-1--fontType": "regular",\\
  "--text-component-1--fontStyle": "normal",\\
  "--text-component-1--fontStretch": "normal",\\
  "--text-component-1--lineHeight": "1.35",\\
  "--text-component-1--marginLeft": "0px",\\
  "--text-component-1--color": "var(--color6)",\\
  "--text-component-1--borderBottomStyle": "none",\\
  "--text-component-1--textDecoration": "none",\\
  "--text-component-1--letterSpacing": "0",\\
  "--text-component-1--textTransform": "none",\\
  "--text-component-1--stroke": "var(--palette-color2)",\\
  "--text-component-1--textAlign": "left",\\
  "--text-component-1--justifyContent": "flex-start",\\
  "--text-component-1--marginTop": "auto",\\
  "--text-component-1--marginBottom": "0",\\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-2--fontSize--desktop": "24px",\\
  "--text-component-2--fontSize--tablet": "20px",\\
  "--text-component-2--fontSize--mobile": "20px",\\
  "--text-component-2--fontFamily": "var(--font1)",\\
  "--text-component-2--fontWeight": "normal",\\
  "--text-component-2--fontType": "regular",\\
  "--text-component-2--fontStyle": "normal",\\
  "--text-component-2--fontStretch": "normal",\\
  "--text-component-2--lineHeight": "1.35",\\
  "--text-component-2--marginLeft": "0px",\\
  "--text-component-2--color": "var(--palette-color1)",\\
  "--text-component-2--borderBottomStyle": "none",\\
  "--text-component-2--textDecoration": "none",\\
  "--text-component-2--letterSpacing": "0.16",\\
  "--text-component-2--textTransform": "none",\\
  "--text-component-2--stroke": "var(--palette-color2)",\\
  "--text-component-2--textAlign": "left",\\
  "--text-component-2--justifyContent": "flex-start",\\
  "--text-component-2--marginTop": "auto",\\
  "--text-component-2--marginBottom": "0",\\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-3--fontSize--desktop": "14px",\\
  "--text-component-3--fontSize--tablet": "14px",\\
  "--text-component-3--fontSize--mobile": "14px",\\
  "--text-component-3--fontFamily": "var(--font1)",\\
  "--text-component-3--fontWeight": "normal",\\
  "--text-component-3--fontType": "regular",\\
  "--text-component-3--fontStyle": "normal",\\
  "--text-component-3--fontStretch": "normal",\\
  "--text-component-3--lineHeight": "1.35",\\
  "--text-component-3--marginLeft": "0px",\\
  "--text-component-3--color": "var(--palette-color6)",\\
  "--text-component-3--borderBottomStyle": "none",\\
  "--text-component-3--textDecoration": "none",\\
  "--text-component-3--letterSpacing": "0.2",\\
  "--text-component-3--textTransform": "uppercase",\\
  "--text-component-3--stroke": "var(--palette-color2)",\\
  "--text-component-3--textAlign": "center",\\
  "--text-component-3--justifyContent": "flex-start",\\
  "--text-component-3--marginTop": "auto",\\
  "--text-component-3--marginBottom": "0",\\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-4--fontSize--desktop": "22px",\\
  "--text-component-4--fontSize--tablet": "20px",\\
  "--text-component-4--fontSize--mobile": "20px",\\
  "--text-component-4--fontFamily": "var(--font1)",\\
  "--text-component-4--fontWeight": "normal",\\
  "--text-component-4--fontType": "regular",\\
  "--text-component-4--fontStyle": "normal",\\
  "--text-component-4--fontStretch": "normal",\\
  "--text-component-4--lineHeight": "1.35",\\
  "--text-component-4--marginLeft": "0px",\\
  "--text-component-4--color": "var(--color6)",\\
  "--text-component-4--borderBottomStyle": "none",\\
  "--text-component-4--textDecoration": "none",\\
  "--text-component-4--letterSpacing": "0.02",\\
  "--text-component-4--textTransform": "none",\\
  "--text-component-4--stroke": "var(--palette-color2)",\\
  "--text-component-4--textAlign": "left",\\
  "--text-component-4--justifyContent": "flex-start",\\
  "--text-component-4--marginTop": "auto",\\
  "--text-component-4--marginBottom": "0",\\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-1--fontSize--desktop": "36px",\\
  "--text-subheading-1--fontSize--tablet": "32px",\\
  "--text-subheading-1--fontSize--mobile": "28px",\\
  "--text-subheading-1--fontFamily": "var(--font2)",\\
  "--text-subheading-1--fontWeight": "normal",\\
  "--text-subheading-1--fontType": "regular",\\
  "--text-subheading-1--fontStyle": "normal",\\
  "--text-subheading-1--fontStretch": "normal",\\
  "--text-subheading-1--lineHeight": "1.1",\\
  "--text-subheading-1--marginLeft": "0px",\\
  "--text-subheading-1--color": "var(--palette-color6)",\\
  "--text-subheading-1--borderBottomStyle": "none",\\
  "--text-subheading-1--textDecoration": "none",\\
  "--text-subheading-1--letterSpacing": "0.05",\\
  "--text-subheading-1--textTransform": "uppercase",\\
  "--text-subheading-1--stroke": "var(--palette-color2)",\\
  "--text-subheading-1--textAlign": "left",\\
  "--text-subheading-1--justifyContent": "flex-start",\\
  "--text-subheading-1--marginTop": "auto",\\
  "--text-subheading-1--marginBottom": "0",\\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-2--fontSize--desktop": "28px",\\
  "--text-subheading-2--fontSize--tablet": "24px",\\
  "--text-subheading-2--fontSize--mobile": "20px",\\
  "--text-subheading-2--fontFamily": "var(--font2)",\\
  "--text-subheading-2--fontWeight": "normal",\\
  "--text-subheading-2--fontType": "bold",\\
  "--text-subheading-2--fontStyle": "normal",\\
  "--text-subheading-2--fontStretch": "normal",\\
  "--text-subheading-2--lineHeight": "1.15",\\
  "--text-subheading-2--marginLeft": "0px",\\
  "--text-subheading-2--color": "var(--palette-color6)",\\
  "--text-subheading-2--borderBottomStyle": "none",\\
  "--text-subheading-2--textDecoration": "none",\\
  "--text-subheading-2--letterSpacing": "0.05",\\
  "--text-subheading-2--textTransform": "none",\\
  "--text-subheading-2--stroke": "var(--palette-color2)",\\
  "--text-subheading-2--textAlign": "left",\\
  "--text-subheading-2--justifyContent": "flex-start",\\
  "--text-subheading-2--marginTop": "auto",\\
  "--text-subheading-2--marginBottom": "0",\\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-3--fontSize--desktop": "26px",\\
  "--text-subheading-3--fontSize--tablet": "22px",\\
  "--text-subheading-3--fontSize--mobile": "18px",\\
  "--text-subheading-3--fontFamily": "var(--font2)",\\
  "--text-subheading-3--fontWeight": "normal",\\
  "--text-subheading-3--fontType": "regular",\\
  "--text-subheading-3--fontStyle": "normal",\\
  "--text-subheading-3--fontStretch": "normal",\\
  "--text-subheading-3--lineHeight": "1.15",\\
  "--text-subheading-3--marginLeft": "0px",\\
  "--text-subheading-3--color": "var(--palette-color6)",\\
  "--text-subheading-3--borderBottomStyle": "none",\\
  "--text-subheading-3--textDecoration": "none",\\
  "--text-subheading-3--letterSpacing": "0",\\
  "--text-subheading-3--textTransform": "none",\\
  "--text-subheading-3--stroke": "var(--palette-color2)",\\
  "--text-subheading-3--textAlign": "center",\\
  "--text-subheading-3--justifyContent": "flex-start",\\
  "--text-subheading-3--marginTop": "auto",\\
  "--text-subheading-3--marginBottom": "0",\\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-4--fontSize--desktop": "24px",\\
  "--text-subheading-4--fontSize--tablet": "20px",\\
  "--text-subheading-4--fontSize--mobile": "16px",\\
  "--text-subheading-4--fontFamily": "var(--font2)",\\
  "--text-subheading-4--fontWeight": "normal",\\
  "--text-subheading-4--fontType": "bold",\\
  "--text-subheading-4--fontStyle": "normal",\\
  "--text-subheading-4--fontStretch": "normal",\\
  "--text-subheading-4--lineHeight": "1.15",\\
  "--text-subheading-4--marginLeft": "0px",\\
  "--text-subheading-4--color": "var(--palette-color0)",\\
  "--text-subheading-4--borderBottomStyle": "none",\\
  "--text-subheading-4--textDecoration": "none",\\
  "--text-subheading-4--letterSpacing": "0.05",\\
  "--text-subheading-4--textTransform": "none",\\
  "--text-subheading-4--stroke": "var(--palette-color2)",\\
  "--text-subheading-4--textAlign": "left",\\
  "--text-subheading-4--justifyContent": "flex-start",\\
  "--text-subheading-4--marginTop": "auto",\\
  "--text-subheading-4--marginBottom": "0",\\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-5--fontSize--desktop": "24px",\\
  "--text-subheading-5--fontSize--tablet": "20px",\\
  "--text-subheading-5--fontSize--mobile": "16px",\\
  "--text-subheading-5--fontFamily": "var(--font1)",\\
  "--text-subheading-5--fontWeight": "normal",\\
  "--text-subheading-5--fontType": "bold",\\
  "--text-subheading-5--fontStyle": "normal",\\
  "--text-subheading-5--fontStretch": "normal",\\
  "--text-subheading-5--lineHeight": "1.15",\\
  "--text-subheading-5--marginLeft": "0px",\\
  "--text-subheading-5--color": "var(--palette-color5)",\\
  "--text-subheading-5--borderBottomStyle": "none",\\
  "--text-subheading-5--textDecoration": "none",\\
  "--text-subheading-5--letterSpacing": "-0.05",\\
  "--text-subheading-5--textTransform": "none",\\
  "--text-subheading-5--stroke": "var(--palette-color2)",\\
  "--text-subheading-5--textAlign": "left",\\
  "--text-subheading-5--justifyContent": "flex-start",\\
  "--text-subheading-5--marginTop": "auto",\\
  "--text-subheading-5--marginBottom": "0",\\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-6--fontSize--desktop": "18px",\\
  "--text-subheading-6--fontSize--tablet": "16px",\\
  "--text-subheading-6--fontSize--mobile": "14px",\\
  "--text-subheading-6--fontFamily": "var(--font2)",\\
  "--text-subheading-6--fontWeight": "normal",\\
  "--text-subheading-6--fontType": "bold",\\
  "--text-subheading-6--fontStyle": "normal",\\
  "--text-subheading-6--fontStretch": "normal",\\
  "--text-subheading-6--lineHeight": "1.25",\\
  "--text-subheading-6--marginLeft": "0px",\\
  "--text-subheading-6--color": "var(--palette-color5)",\\
  "--text-subheading-6--borderBottomStyle": "none",\\
  "--text-subheading-6--textDecoration": "none",\\
  "--text-subheading-6--letterSpacing": "0",\\
  "--text-subheading-6--textTransform": "none",\\
  "--text-subheading-6--stroke": "var(--palette-color2)",\\
  "--text-subheading-6--textAlign": "left",\\
  "--text-subheading-6--justifyContent": "flex-start",\\
  "--text-subheading-6--marginTop": "auto",\\
  "--text-subheading-6--marginBottom": "0",\\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-1--fontSize--desktop": "20px",\\
  "--text-detail-1--fontSize--tablet": "18px",\\
  "--text-detail-1--fontSize--mobile": "16px",\\
  "--text-detail-1--fontFamily": "var(--font2)",\\
  "--text-detail-1--fontWeight": "normal",\\
  "--text-detail-1--fontType": "regular",\\
  "--text-detail-1--fontStyle": "normal",\\
  "--text-detail-1--fontStretch": "normal",\\
  "--text-detail-1--lineHeight": "1.2",\\
  "--text-detail-1--marginLeft": "0px",\\
  "--text-detail-1--color": "var(--palette-color6)",\\
  "--text-detail-1--borderBottomStyle": "none",\\
  "--text-detail-1--textDecoration": "none",\\
  "--text-detail-1--letterSpacing": "0",\\
  "--text-detail-1--textTransform": "uppercase",\\
  "--text-detail-1--stroke": "var(--palette-color5)",\\
  "--text-detail-1--textAlign": "left",\\
  "--text-detail-1--justifyContent": "flex-start",\\
  "--text-detail-1--marginTop": "auto",\\
  "--text-detail-1--marginBottom": "0",\\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-2--fontSize--desktop": "16px",\\
  "--text-detail-2--fontSize--tablet": "14px",\\
  "--text-detail-2--fontSize--mobile": "12px",\\
  "--text-detail-2--fontFamily": "var(--font2)",\\
  "--text-detail-2--fontWeight": "normal",\\
  "--text-detail-2--fontType": "bold",\\
  "--text-detail-2--fontStyle": "normal",\\
  "--text-detail-2--fontStretch": "normal",\\
  "--text-detail-2--lineHeight": "1.3",\\
  "--text-detail-2--marginLeft": "0px",\\
  "--text-detail-2--color": "var(--palette-color6)",\\
  "--text-detail-2--borderBottomStyle": "none",\\
  "--text-detail-2--textDecoration": "none",\\
  "--text-detail-2--letterSpacing": "0",\\
  "--text-detail-2--textTransform": "uppercase",\\
  "--text-detail-2--stroke": "var(--palette-color2)",\\
  "--text-detail-2--textAlign": "left",\\
  "--text-detail-2--justifyContent": "flex-start",\\
  "--text-detail-2--marginTop": "auto",\\
  "--text-detail-2--marginBottom": "0",\\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-3--fontSize--desktop": "16px",\\
  "--text-detail-3--fontSize--tablet": "14px",\\
  "--text-detail-3--fontSize--mobile": "12px",\\
  "--text-detail-3--fontFamily": "var(--font2)",\\
  "--text-detail-3--fontWeight": "normal",\\
  "--text-detail-3--fontType": "regular",\\
  "--text-detail-3--fontStyle": "normal",\\
  "--text-detail-3--fontStretch": "normal",\\
  "--text-detail-3--lineHeight": "1.35",\\
  "--text-detail-3--marginLeft": "0px",\\
  "--text-detail-3--color": "var(--palette-color4)",\\
  "--text-detail-3--borderBottomStyle": "none",\\
  "--text-detail-3--textDecoration": "none",\\
  "--text-detail-3--letterSpacing": "0.2",\\
  "--text-detail-3--textTransform": "uppercase",\\
  "--text-detail-3--stroke": "var(--palette-color2)",\\
  "--text-detail-3--textAlign": "left",\\
  "--text-detail-3--justifyContent": "flex-start",\\
  "--text-detail-3--marginTop": "auto",\\
  "--text-detail-3--marginBottom": "0",\\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-4--fontSize--desktop": "22px",\\
  "--text-detail-4--fontSize--tablet": "20px",\\
  "--text-detail-4--fontSize--mobile": "20px",\\
  "--text-detail-4--fontFamily": "var(--font1)",\\
  "--text-detail-4--fontWeight": "normal",\\
  "--text-detail-4--fontType": "regular",\\
  "--text-detail-4--fontStyle": "normal",\\
  "--text-detail-4--fontStretch": "normal",\\
  "--text-detail-4--lineHeight": "1.35",\\
  "--text-detail-4--marginLeft": "0px",\\
  "--text-detail-4--color": "var(--palette-color5)",\\
  "--text-detail-4--borderBottomStyle": "none",\\
  "--text-detail-4--textDecoration": "none",\\
  "--text-detail-4--letterSpacing": "0",\\
  "--text-detail-4--textTransform": "none",\\
  "--text-detail-4--stroke": "var(--palette-color2)",\\
  "--text-detail-4--textAlign": "center",\\
  "--text-detail-4--justifyContent": "flex-start",\\
  "--text-detail-4--marginTop": "auto",\\
  "--text-detail-4--marginBottom": "0",\\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-1--fontSize--desktop": "36px",\\
  "--text-variable-1--fontSize--tablet": "32px",\\
  "--text-variable-1--fontSize--mobile": "30px",\\
  "--text-variable-1--fontFamily": "var(--font2)",\\
  "--text-variable-1--fontWeight": "normal",\\
  "--text-variable-1--fontType": "bold",\\
  "--text-variable-1--fontStyle": "normal",\\
  "--text-variable-1--fontStretch": "normal",\\
  "--text-variable-1--lineHeight": "1.2",\\
  "--text-variable-1--marginLeft": "0px",\\
  "--text-variable-1--color": "var(--palette-color7)",\\
  "--text-variable-1--borderBottomStyle": "none",\\
  "--text-variable-1--textDecoration": "none",\\
  "--text-variable-1--letterSpacing": "0.02",\\
  "--text-variable-1--textTransform": "none",\\
  "--text-variable-1--stroke": "var(--palette-color2)",\\
  "--text-variable-1--textAlign": "left",\\
  "--text-variable-1--justifyContent": "flex-start",\\
  "--text-variable-1--marginTop": "auto",\\
  "--text-variable-1--marginBottom": "0",\\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-2--fontSize--desktop": "24px",\\
  "--text-variable-2--fontSize--tablet": "22px",\\
  "--text-variable-2--fontSize--mobile": "20px",\\
  "--text-variable-2--fontFamily": "var(--font2)",\\
  "--text-variable-2--fontWeight": "normal",\\
  "--text-variable-2--fontType": "bold",\\
  "--text-variable-2--fontStyle": "normal",\\
  "--text-variable-2--fontStretch": "normal",\\
  "--text-variable-2--lineHeight": "1.15",\\
  "--text-variable-2--marginLeft": "0px",\\
  "--text-variable-2--color": "var(--palette-color6)",\\
  "--text-variable-2--borderBottomStyle": "none",\\
  "--text-variable-2--textDecoration": "none",\\
  "--text-variable-2--letterSpacing": "0",\\
  "--text-variable-2--textTransform": "none",\\
  "--text-variable-2--stroke": "var(--palette-color2)",\\
  "--text-variable-2--textAlign": "left",\\
  "--text-variable-2--justifyContent": "flex-start",\\
  "--text-variable-2--marginTop": "auto",\\
  "--text-variable-2--marginBottom": "0",\\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-3--fontSize--desktop": "20px",\\
  "--text-variable-3--fontSize--tablet": "18px",\\
  "--text-variable-3--fontSize--mobile": "16px",\\
  "--text-variable-3--fontFamily": "var(--font1)",\\
  "--text-variable-3--fontWeight": "normal",\\
  "--text-variable-3--fontType": "bold",\\
  "--text-variable-3--fontStyle": "normal",\\
  "--text-variable-3--fontStretch": "normal",\\
  "--text-variable-3--lineHeight": "1.2",\\
  "--text-variable-3--marginLeft": "0px",\\
  "--text-variable-3--color": "var(--palette-color6)",\\
  "--text-variable-3--borderBottomStyle": "none",\\
  "--text-variable-3--textDecoration": "none",\\
  "--text-variable-3--letterSpacing": "0",\\
  "--text-variable-3--textTransform": "none",\\
  "--text-variable-3--stroke": "var(--palette-color2)",\\
  "--text-variable-3--textAlign": "left",\\
  "--text-variable-3--justifyContent": "flex-start",\\
  "--text-variable-3--marginTop": "auto",\\
  "--text-variable-3--marginBottom": "0",\\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-4--fontSize--desktop": "16px",\\
  "--text-variable-4--fontSize--tablet": "14px",\\
  "--text-variable-4--fontSize--mobile": "12px",\\
  "--text-variable-4--fontFamily": "var(--font2)",\\
  "--text-variable-4--fontWeight": "normal",\\
  "--text-variable-4--fontType": "bold",\\
  "--text-variable-4--fontStyle": "normal",\\
  "--text-variable-4--fontStretch": "normal",\\
  "--text-variable-4--lineHeight": "1.3",\\
  "--text-variable-4--marginLeft": "0px",\\
  "--text-variable-4--color": "var(--palette-color6)",\\
  "--text-variable-4--borderBottomStyle": "none",\\
  "--text-variable-4--textDecoration": "none",\\
  "--text-variable-4--letterSpacing": "0.02",\\
  "--text-variable-4--textTransform": "none",\\
  "--text-variable-4--stroke": "var(--palette-color2)",\\
  "--text-variable-4--textAlign": "left",\\
  "--text-variable-4--justifyContent": "flex-start",\\
  "--text-variable-4--marginTop": "auto",\\
  "--text-variable-4--marginBottom": "0",\\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-1--fontSize--desktop": "48px",\\
  "--text-question-1--fontSize--tablet": "20px",\\
  "--text-question-1--fontSize--mobile": "20px",\\
  "--text-question-1--fontFamily": "var(--font1)",\\
  "--text-question-1--fontWeight": "normal",\\
  "--text-question-1--fontType": "regular",\\
  "--text-question-1--fontStyle": "normal",\\
  "--text-question-1--fontStretch": "normal",\\
  "--text-question-1--lineHeight": "1.35",\\
  "--text-question-1--marginLeft": "0px",\\
  "--text-question-1--color": "var(--palette-color5)",\\
  "--text-question-1--borderBottomStyle": "none",\\
  "--text-question-1--textDecoration": "none",\\
  "--text-question-1--letterSpacing": "0",\\
  "--text-question-1--textTransform": "none",\\
  "--text-question-1--stroke": "var(--palette-color2)",\\
  "--text-question-1--textAlign": "left",\\
  "--text-question-1--justifyContent": "flex-start",\\
  "--text-question-1--marginTop": "auto",\\
  "--text-question-1--marginBottom": "0",\\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-2--fontSize--desktop": "24px",\\
  "--text-question-2--fontSize--tablet": "20px",\\
  "--text-question-2--fontSize--mobile": "20px",\\
  "--text-question-2--fontFamily": "var(--font1)",\\
  "--text-question-2--fontWeight": "normal",\\
  "--text-question-2--fontType": "bold",\\
  "--text-question-2--fontStyle": "normal",\\
  "--text-question-2--fontStretch": "normal",\\
  "--text-question-2--lineHeight": "1.35",\\
  "--text-question-2--marginLeft": "0px",\\
  "--text-question-2--color": "var(--palette-color5)",\\
  "--text-question-2--borderBottomStyle": "none",\\
  "--text-question-2--textDecoration": "none",\\
  "--text-question-2--letterSpacing": "0",\\
  "--text-question-2--textTransform": "none",\\
  "--text-question-2--stroke": "var(--palette-color2)",\\
  "--text-question-2--textAlign": "left",\\
  "--text-question-2--justifyContent": "flex-start",\\
  "--text-question-2--marginTop": "auto",\\
  "--text-question-2--marginBottom": "0",\\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-1--fontSize--desktop": "16px",\\
  "--text-button-1--fontSize--tablet": "16px",\\
  "--text-button-1--fontSize--mobile": "16px",\\
  "--text-button-1--fontFamily": "var(--font2)",\\
  "--text-button-1--fontWeight": "normal",\\
  "--text-button-1--fontType": "regular",\\
  "--text-button-1--fontStyle": "normal",\\
  "--text-button-1--fontStretch": "normal",\\
  "--text-button-1--lineHeight": "1.25",\\
  "--text-button-1--marginLeft": "0px",\\
  "--text-button-1--color": "var(--palette-color7)",\\
  "--text-button-1--borderBottomStyle": "none",\\
  "--text-button-1--textDecoration": "none",\\
  "--text-button-1--letterSpacing": "0.12",\\
  "--text-button-1--textTransform": "uppercase",\\
  "--text-button-1--stroke": "var(--palette-color2)",\\
  "--text-button-1--textAlign": "center",\\
  "--text-button-1--justifyContent": "flex-start",\\
  "--text-button-1--marginTop": "auto",\\
  "--text-button-1--marginBottom": "0",\\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-2--fontSize--desktop": "16px",\\
  "--text-button-2--fontSize--tablet": "16px",\\
  "--text-button-2--fontSize--mobile": "16px",\\
  "--text-button-2--fontFamily": "var(--font2)",\\
  "--text-button-2--fontWeight": "normal",\\
  "--text-button-2--fontType": "regular",\\
  "--text-button-2--fontStyle": "normal",\\
  "--text-button-2--fontStretch": "normal",\\
  "--text-button-2--lineHeight": "1.25",\\
  "--text-button-2--marginLeft": "0px",\\
  "--text-button-2--color": "var(--palette-color0)",\\
  "--text-button-2--borderBottomStyle": "none",\\
  "--text-button-2--textDecoration": "none",\\
  "--text-button-2--letterSpacing": "0.12",\\
  "--text-button-2--textTransform": "uppercase",\\
  "--text-button-2--stroke": "var(--palette-color2)",\\
  "--text-button-2--textAlign": "center",\\
  "--text-button-2--justifyContent": "flex-start",\\
  "--text-button-2--marginTop": "auto",\\
  "--text-button-2--marginBottom": "0",\\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-3--fontSize--desktop": "16px",\\
  "--text-button-3--fontSize--tablet": "16px",\\
  "--text-button-3--fontSize--mobile": "16px",\\
  "--text-button-3--fontFamily": "var(--font2)",\\
  "--text-button-3--fontWeight": "normal",\\
  "--text-button-3--fontType": "regular",\\
  "--text-button-3--fontStyle": "normal",\\
  "--text-button-3--fontStretch": "normal",\\
  "--text-button-3--lineHeight": "1.25",\\
  "--text-button-3--marginLeft": "0px",\\
  "--text-button-3--color": "var(--palette-color5)",\\
  "--text-button-3--borderBottomStyle": "none",\\
  "--text-button-3--textDecoration": "none",\\
  "--text-button-3--letterSpacing": "0.12",\\
  "--text-button-3--textTransform": "uppercase",\\
  "--text-button-3--stroke": "var(--palette-color2)",\\
  "--text-button-3--textAlign": "center",\\
  "--text-button-3--justifyContent": "flex-start",\\
  "--text-button-3--marginTop": "auto",\\
  "--text-button-3--marginBottom": "0",\\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-4--fontSize--desktop": "16px",\\
  "--text-button-4--fontSize--tablet": "16px",\\
  "--text-button-4--fontSize--mobile": "16px",\\
  "--text-button-4--fontFamily": "var(--font2)",\\
  "--text-button-4--fontWeight": "normal",\\
  "--text-button-4--fontType": "regular",\\
  "--text-button-4--fontStyle": "normal",\\
  "--text-button-4--fontStretch": "normal",\\
  "--text-button-4--lineHeight": "1.25",\\
  "--text-button-4--marginLeft": "0px",\\
  "--text-button-4--color": "var(--palette-color4)",\\
  "--text-button-4--borderBottomStyle": "none",\\
  "--text-button-4--textDecoration": "none",\\
  "--text-button-4--letterSpacing": "0.12",\\
  "--text-button-4--textTransform": "uppercase",\\
  "--text-button-4--stroke": "var(--palette-color2)",\\
  "--text-button-4--textAlign": "center",\\
  "--text-button-4--justifyContent": "flex-start",\\
  "--text-button-4--marginTop": "auto",\\
  "--text-button-4--marginBottom": "0",\\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-1--fontSize--desktop": "18px",\\
  "--text-uic-1--fontSize--tablet": "18px",\\
  "--text-uic-1--fontSize--mobile": "18px",\\
  "--text-uic-1--fontFamily": "var(--font1)",\\
  "--text-uic-1--fontWeight": "normal",\\
  "--text-uic-1--fontType": "italic",\\
  "--text-uic-1--fontStyle": "normal",\\
  "--text-uic-1--fontStretch": "normal",\\
  "--text-uic-1--lineHeight": "1.35",\\
  "--text-uic-1--marginLeft": "0px",\\
  "--text-uic-1--color": "var(--palette-color4)",\\
  "--text-uic-1--borderBottomStyle": "none",\\
  "--text-uic-1--textDecoration": "none",\\
  "--text-uic-1--letterSpacing": "0",\\
  "--text-uic-1--textTransform": "none",\\
  "--text-uic-1--stroke": "var(--palette-color2)",\\
  "--text-uic-1--textAlign": "left",\\
  "--text-uic-1--justifyContent": "flex-start",\\
  "--text-uic-1--marginTop": "auto",\\
  "--text-uic-1--marginBottom": "0",\\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-2--fontSize--desktop": "18px",\\
  "--text-uic-2--fontSize--tablet": "18px",\\
  "--text-uic-2--fontSize--mobile": "18px",\\
  "--text-uic-2--fontFamily": "var(--font1)",\\
  "--text-uic-2--fontWeight": "normal",\\
  "--text-uic-2--fontType": "italic",\\
  "--text-uic-2--fontStyle": "normal",\\
  "--text-uic-2--fontStretch": "normal",\\
  "--text-uic-2--lineHeight": "1.35",\\
  "--text-uic-2--marginLeft": "0px",\\
  "--text-uic-2--color": "var(--palette-color1)",\\
  "--text-uic-2--borderBottomStyle": "none",\\
  "--text-uic-2--textDecoration": "none",\\
  "--text-uic-2--letterSpacing": "0",\\
  "--text-uic-2--textTransform": "none",\\
  "--text-uic-2--stroke": "var(--palette-color2)",\\
  "--text-uic-2--textAlign": "left",\\
  "--text-uic-2--justifyContent": "flex-start",\\
  "--text-uic-2--marginTop": "auto",\\
  "--text-uic-2--marginBottom": "0",\\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-3--fontSize--desktop": "22px",\\
  "--text-uic-3--fontSize--tablet": "22px",\\
  "--text-uic-3--fontSize--mobile": "22px",\\
  "--text-uic-3--fontFamily": "var(--font1)",\\
  "--text-uic-3--fontWeight": "normal",\\
  "--text-uic-3--fontType": "regular",\\
  "--text-uic-3--fontStyle": "normal",\\
  "--text-uic-3--fontStretch": "normal",\\
  "--text-uic-3--lineHeight": "1.25",\\
  "--text-uic-3--marginLeft": "0px",\\
  "--text-uic-3--color": "var(--palette-color5)",\\
  "--text-uic-3--borderBottomStyle": "none",\\
  "--text-uic-3--textDecoration": "none",\\
  "--text-uic-3--letterSpacing": "0",\\
  "--text-uic-3--textTransform": "none",\\
  "--text-uic-3--stroke": "var(--palette-color2)",\\
  "--text-uic-3--textAlign": "left",\\
  "--text-uic-3--justifyContent": "flex-start",\\
  "--text-uic-3--marginTop": "auto",\\
  "--text-uic-3--marginBottom": "0",\\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-4--fontSize--desktop": "22px",\\
  "--text-uic-4--fontSize--tablet": "22px",\\
  "--text-uic-4--fontSize--mobile": "22px",\\
  "--text-uic-4--fontFamily": "var(--font1)",\\
  "--text-uic-4--fontWeight": "normal",\\
  "--text-uic-4--fontType": "regular",\\
  "--text-uic-4--fontStyle": "normal",\\
  "--text-uic-4--fontStretch": "normal",\\
  "--text-uic-4--lineHeight": "1.25",\\
  "--text-uic-4--marginLeft": "0px",\\
  "--text-uic-4--color": "var(--palette-color4)",\\
  "--text-uic-4--borderBottomStyle": "none",\\
  "--text-uic-4--textDecoration": "none",\\
  "--text-uic-4--letterSpacing": "0",\\
  "--text-uic-4--textTransform": "none",\\
  "--text-uic-4--stroke": "var(--palette-color2)",\\
  "--text-uic-4--textAlign": "left",\\
  "--text-uic-4--justifyContent": "flex-start",\\
  "--text-uic-4--marginTop": "auto",\\
  "--text-uic-4--marginBottom": "0",\\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-5--fontSize--desktop": "22px",\\
  "--text-uic-5--fontSize--tablet": "22px",\\
  "--text-uic-5--fontSize--mobile": "22px",\\
  "--text-uic-5--fontFamily": "var(--font1)",\\
  "--text-uic-5--fontWeight": "normal",\\
  "--text-uic-5--fontType": "regular",\\
  "--text-uic-5--fontStyle": "normal",\\
  "--text-uic-5--fontStretch": "normal",\\
  "--text-uic-5--lineHeight": "1.25",\\
  "--text-uic-5--marginLeft": "0px",\\
  "--text-uic-5--color": "var(--palette-color3)",\\
  "--text-uic-5--borderBottomStyle": "none",\\
  "--text-uic-5--textDecoration": "none",\\
  "--text-uic-5--letterSpacing": "0",\\
  "--text-uic-5--textTransform": "none",\\
  "--text-uic-5--stroke": "var(--palette-color2)",\\
  "--text-uic-5--textAlign": "left",\\
  "--text-uic-5--justifyContent": "flex-start",\\
  "--text-uic-5--marginTop": "auto",\\
  "--text-uic-5--marginBottom": "0",\\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-6--fontSize--desktop": "16px",\\
  "--text-uic-6--fontSize--tablet": "16px",\\
  "--text-uic-6--fontSize--mobile": "16px",\\
  "--text-uic-6--fontFamily": "var(--font2)",\\
  "--text-uic-6--fontWeight": "normal",\\
  "--text-uic-6--fontType": "bold",\\
  "--text-uic-6--fontStyle": "normal",\\
  "--text-uic-6--fontStretch": "normal",\\
  "--text-uic-6--lineHeight": "1.5",\\
  "--text-uic-6--marginLeft": "0px",\\
  "--text-uic-6--color": "var(--palette-color7)",\\
  "--text-uic-6--borderBottomStyle": "none",\\
  "--text-uic-6--textDecoration": "none",\\
  "--text-uic-6--letterSpacing": "0.12",\\
  "--text-uic-6--textTransform": "none",\\
  "--text-uic-6--stroke": "var(--palette-color2)",\\
  "--text-uic-6--textAlign": "left",\\
  "--text-uic-6--justifyContent": "flex-start",\\
  "--text-uic-6--marginTop": "auto",\\
  "--text-uic-6--marginBottom": "0",\\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-closedcaptions--fontSize--desktop": "24px",\\
  "--text-closedcaptions--fontSize--tablet": "24px",\\
  "--text-closedcaptions--fontSize--mobile": "24px",\\
  "--text-closedcaptions--fontFamily": "var(--font1)",\\
  "--text-closedcaptions--fontWeight": "normal",\\
  "--text-closedcaptions--fontType": "regular",\\
  "--text-closedcaptions--fontStyle": "normal",\\
  "--text-closedcaptions--fontStretch": "normal",\\
  "--text-closedcaptions--lineHeight": "1.35",\\
  "--text-closedcaptions--marginLeft": "0px",\\
  "--text-closedcaptions--color": "var(--white)",\\
  "--text-closedcaptions--borderBottomStyle": "none",\\
  "--text-closedcaptions--textDecoration": "none",\\
  "--text-closedcaptions--letterSpacing": "0",\\
  "--text-closedcaptions--textTransform": "none",\\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\\
  "--text-closedcaptions--textAlign": "center",\\
  "--text-closedcaptions--justifyContent": "flex-start",\\
  "--text-closedcaptions--marginTop": "auto",\\
  "--text-closedcaptions--marginBottom": "0",\\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption--fontSize--desktop": "24px",\\
  "--text-caption--fontSize--tablet": "24px",\\
  "--text-caption--fontSize--mobile": "24px",\\
  "--text-caption--fontFamily": "var(--font1)",\\
  "--text-caption--fontWeight": "normal",\\
  "--text-caption--fontType": "regular",\\
  "--text-caption--fontStyle": "normal",\\
  "--text-caption--fontStretch": "normal",\\
  "--text-caption--lineHeight": "1.35",\\
  "--text-caption--marginLeft": "0px",\\
  "--text-caption--color": "var(--palette-color6)",\\
  "--text-caption--borderBottomStyle": "none",\\
  "--text-caption--textDecoration": "none",\\
  "--text-caption--letterSpacing": "0",\\
  "--text-caption--textTransform": "none",\\
  "--text-caption--stroke": "var(--palette-color2)",\\
  "--text-caption--textAlign": "center",\\
  "--text-caption--justifyContent": "flex-start",\\
  "--text-caption--marginTop": "auto",\\
  "--text-caption--marginBottom": "0",\\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_correct--fontSize--desktop": "24px",\\
  "--text-caption_correct--fontSize--tablet": "24px",\\
  "--text-caption_correct--fontSize--mobile": "24px",\\
  "--text-caption_correct--fontFamily": "var(--font1)",\\
  "--text-caption_correct--fontWeight": "normal",\\
  "--text-caption_correct--fontType": "regular",\\
  "--text-caption_correct--fontStyle": "normal",\\
  "--text-caption_correct--fontStretch": "normal",\\
  "--text-caption_correct--lineHeight": "1.35",\\
  "--text-caption_correct--marginLeft": "0px",\\
  "--text-caption_correct--color": "var(--palette-color6)",\\
  "--text-caption_correct--borderBottomStyle": "none",\\
  "--text-caption_correct--textDecoration": "none",\\
  "--text-caption_correct--letterSpacing": "0",\\
  "--text-caption_correct--textTransform": "none",\\
  "--text-caption_correct--stroke": "var(--palette-color2)",\\
  "--text-caption_correct--textAlign": "center",\\
  "--text-caption_correct--justifyContent": "flex-start",\\
  "--text-caption_correct--marginTop": "auto",\\
  "--text-caption_correct--marginBottom": "0",\\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incorrect--fontSize--desktop": "24px",\\
  "--text-caption_incorrect--fontSize--tablet": "24px",\\
  "--text-caption_incorrect--fontSize--mobile": "24px",\\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\\
  "--text-caption_incorrect--fontWeight": "normal",\\
  "--text-caption_incorrect--fontType": "regular",\\
  "--text-caption_incorrect--fontStyle": "normal",\\
  "--text-caption_incorrect--fontStretch": "normal",\\
  "--text-caption_incorrect--lineHeight": "1.35",\\
  "--text-caption_incorrect--marginLeft": "0px",\\
  "--text-caption_incorrect--color": "var(--palette-color6)",\\
  "--text-caption_incorrect--borderBottomStyle": "none",\\
  "--text-caption_incorrect--textDecoration": "none",\\
  "--text-caption_incorrect--letterSpacing": "0",\\
  "--text-caption_incorrect--textTransform": "none",\\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\\
  "--text-caption_incorrect--textAlign": "center",\\
  "--text-caption_incorrect--justifyContent": "flex-start",\\
  "--text-caption_incorrect--marginTop": "auto",\\
  "--text-caption_incorrect--marginBottom": "0",\\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incomplete--fontSize--desktop": "24px",\\
  "--text-caption_incomplete--fontSize--tablet": "24px",\\
  "--text-caption_incomplete--fontSize--mobile": "24px",\\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\\
  "--text-caption_incomplete--fontWeight": "normal",\\
  "--text-caption_incomplete--fontType": "regular",\\
  "--text-caption_incomplete--fontStyle": "normal",\\
  "--text-caption_incomplete--fontStretch": "normal",\\
  "--text-caption_incomplete--lineHeight": "1.35",\\
  "--text-caption_incomplete--marginLeft": "0px",\\
  "--text-caption_incomplete--color": "var(--palette-color6)",\\
  "--text-caption_incomplete--borderBottomStyle": "none",\\
  "--text-caption_incomplete--textDecoration": "none",\\
  "--text-caption_incomplete--letterSpacing": "0",\\
  "--text-caption_incomplete--textTransform": "none",\\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\\
  "--text-caption_incomplete--textAlign": "center",\\
  "--text-caption_incomplete--justifyContent": "flex-start",\\
  "--text-caption_incomplete--marginTop": "auto",\\
  "--text-caption_incomplete--marginBottom": "0",\\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_hint--fontSize--desktop": "24px",\\
  "--text-caption_hint--fontSize--tablet": "24px",\\
  "--text-caption_hint--fontSize--mobile": "24px",\\
  "--text-caption_hint--fontFamily": "var(--font1)",\\
  "--text-caption_hint--fontWeight": "normal",\\
  "--text-caption_hint--fontType": "regular",\\
  "--text-caption_hint--fontStyle": "normal",\\
  "--text-caption_hint--fontStretch": "normal",\\
  "--text-caption_hint--lineHeight": "1.35",\\
  "--text-caption_hint--marginLeft": "0px",\\
  "--text-caption_hint--color": "var(--palette-color6)",\\
  "--text-caption_hint--borderBottomStyle": "none",\\
  "--text-caption_hint--textDecoration": "none",\\
  "--text-caption_hint--letterSpacing": "0",\\
  "--text-caption_hint--textTransform": "none",\\
  "--text-caption_hint--stroke": "var(--palette-color2)",\\
  "--text-caption_hint--textAlign": "center",\\
  "--text-caption_hint--justifyContent": "flex-start",\\
  "--text-caption_hint--marginTop": "auto",\\
  "--text-caption_hint--marginBottom": "0",\\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_retry--fontSize--desktop": "24px",\\
  "--text-caption_retry--fontSize--tablet": "24px",\\
  "--text-caption_retry--fontSize--mobile": "24px",\\
  "--text-caption_retry--fontFamily": "var(--font1)",\\
  "--text-caption_retry--fontWeight": "normal",\\
  "--text-caption_retry--fontType": "regular",\\
  "--text-caption_retry--fontStyle": "normal",\\
  "--text-caption_retry--fontStretch": "normal",\\
  "--text-caption_retry--lineHeight": "1.35",\\
  "--text-caption_retry--marginLeft": "0px",\\
  "--text-caption_retry--color": "var(--palette-color6)",\\
  "--text-caption_retry--borderBottomStyle": "none",\\
  "--text-caption_retry--textDecoration": "none",\\
  "--text-caption_retry--letterSpacing": "0",\\
  "--text-caption_retry--textTransform": "none",\\
  "--text-caption_retry--stroke": "var(--palette-color2)",\\
  "--text-caption_retry--textAlign": "center",\\
  "--text-caption_retry--justifyContent": "flex-start",\\
  "--text-caption_retry--marginTop": "auto",\\
  "--text-caption_retry--marginBottom": "0",\\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_timeout--fontSize--desktop": "24px",\\
  "--text-caption_timeout--fontSize--tablet": "24px",\\
  "--text-caption_timeout--fontSize--mobile": "24px",\\
  "--text-caption_timeout--fontFamily": "var(--font1)",\\
  "--text-caption_timeout--fontWeight": "normal",\\
  "--text-caption_timeout--fontType": "regular",\\
  "--text-caption_timeout--fontStyle": "normal",\\
  "--text-caption_timeout--fontStretch": "normal",\\
  "--text-caption_timeout--lineHeight": "1.35",\\
  "--text-caption_timeout--marginLeft": "0px",\\
  "--text-caption_timeout--color": "var(--palette-color6)",\\
  "--text-caption_timeout--borderBottomStyle": "none",\\
  "--text-caption_timeout--textDecoration": "none",\\
  "--text-caption_timeout--letterSpacing": "0",\\
  "--text-caption_timeout--textTransform": "none",\\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\\
  "--text-caption_timeout--textAlign": "center",\\
  "--text-caption_timeout--justifyContent": "flex-start",\\
  "--text-caption_timeout--marginTop": "auto",\\
  "--text-caption_timeout--marginBottom": "0",\\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_1--fontSize--desktop": "18px",\\
  "--text-caption_1--fontSize--tablet": "18px",\\
  "--text-caption_1--fontSize--mobile": "16px",\\
  "--text-caption_1--fontFamily": "var(--font2)",\\
  "--text-caption_1--fontWeight": "normal",\\
  "--text-caption_1--fontType": "regular",\\
  "--text-caption_1--fontStyle": "normal",\\
  "--text-caption_1--fontStretch": "normal",\\
  "--text-caption_1--lineHeight": "1.2",\\
  "--text-caption_1--marginLeft": "0px",\\
  "--text-caption_1--color": "#FFFFFF",\\
  "--text-caption_1--borderBottomStyle": "none",\\
  "--text-caption_1--textDecoration": "none",\\
  "--text-caption_1--letterSpacing": "0",\\
  "--text-caption_1--textTransform": "none",\\
  "--text-caption_1--stroke": "#00000000",\\
  "--text-caption_1--textAlign": "left",\\
  "--text-caption_1--justifyContent": "flex-start",\\
  "--text-caption_1--marginTop": "auto",\\
  "--text-caption_1--marginBottom": "0",\\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_2--fontSize--desktop": "20px",\\
  "--text-caption_2--fontSize--tablet": "20px",\\
  "--text-caption_2--fontSize--mobile": "18px",\\
  "--text-caption_2--fontFamily": "var(--font2)",\\
  "--text-caption_2--fontWeight": "normal",\\
  "--text-caption_2--fontType": "bold",\\
  "--text-caption_2--fontStyle": "normal",\\
  "--text-caption_2--fontStretch": "normal",\\
  "--text-caption_2--lineHeight": "1.2",\\
  "--text-caption_2--marginLeft": "0px",\\
  "--text-caption_2--color": "#FFFFFF",\\
  "--text-caption_2--borderBottomStyle": "none",\\
  "--text-caption_2--textDecoration": "none",\\
  "--text-caption_2--letterSpacing": "0",\\
  "--text-caption_2--textTransform": "none",\\
  "--text-caption_2--stroke": "#00000000",\\
  "--text-caption_2--textAlign": "left",\\
  "--text-caption_2--justifyContent": "flex-start",\\
  "--text-caption_2--marginTop": "auto",\\
  "--text-caption_2--marginBottom": "0",\\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_3--fontSize--desktop": "24px",\\
  "--text-caption_3--fontSize--tablet": "24px",\\
  "--text-caption_3--fontSize--mobile": "22px",\\
  "--text-caption_3--fontFamily": "var(--font1)",\\
  "--text-caption_3--fontWeight": "normal",\\
  "--text-caption_3--fontType": "italic",\\
  "--text-caption_3--fontStyle": "normal",\\
  "--text-caption_3--fontStretch": "normal",\\
  "--text-caption_3--lineHeight": "1.2",\\
  "--text-caption_3--marginLeft": "0px",\\
  "--text-caption_3--color": "#FFFFFF",\\
  "--text-caption_3--borderBottomStyle": "none",\\
  "--text-caption_3--textDecoration": "none",\\
  "--text-caption_3--letterSpacing": "0",\\
  "--text-caption_3--textTransform": "none",\\
  "--text-caption_3--stroke": "#00000000",\\
  "--text-caption_3--textAlign": "left",\\
  "--text-caption_3--justifyContent": "flex-start",\\
  "--text-caption_3--marginTop": "auto",\\
  "--text-caption_3--marginBottom": "0",\\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_4--fontSize--desktop": "22px",\\
  "--text-caption_4--fontSize--tablet": "22px",\\
  "--text-caption_4--fontSize--mobile": "20px",\\
  "--text-caption_4--fontFamily": "var(--font2)",\\
  "--text-caption_4--fontWeight": "normal",\\
  "--text-caption_4--fontType": "italic",\\
  "--text-caption_4--fontStyle": "normal",\\
  "--text-caption_4--fontStretch": "normal",\\
  "--text-caption_4--lineHeight": "1.3",\\
  "--text-caption_4--marginLeft": "0px",\\
  "--text-caption_4--color": "#666666",\\
  "--text-caption_4--borderBottomStyle": "none",\\
  "--text-caption_4--textDecoration": "none",\\
  "--text-caption_4--letterSpacing": "0",\\
  "--text-caption_4--textTransform": "none",\\
  "--text-caption_4--stroke": "#00000000",\\
  "--text-caption_4--textAlign": "left",\\
  "--text-caption_4--justifyContent": "flex-start",\\
  "--text-caption_4--marginTop": "auto",\\
  "--text-caption_4--marginBottom": "0",\\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-comment-box--fontSize--desktop": "20px",\\
  "--text-comment-box--fontSize--tablet": "20px",\\
  "--text-comment-box--fontSize--mobile": "20px",\\
  "--text-comment-box--fontFamily": "var(--font1)",\\
  "--text-comment-box--fontWeight": "normal",\\
  "--text-comment-box--fontType": "regular",\\
  "--text-comment-box--fontStyle": "normal",\\
  "--text-comment-box--fontStretch": "normal",\\
  "--text-comment-box--lineHeight": "1.35",\\
  "--text-comment-box--marginLeft": "0px",\\
  "--text-comment-box--color": "var(--palette-color6)",\\
  "--text-comment-box--borderBottomStyle": "none",\\
  "--text-comment-box--textDecoration": "none",\\
  "--text-comment-box--letterSpacing": "0",\\
  "--text-comment-box--textTransform": "none",\\
  "--text-comment-box--stroke": "var(--palette-color2)",\\
  "--text-comment-box--textAlign": "center",\\
  "--text-comment-box--justifyContent": "flex-start",\\
  "--text-comment-box--marginTop": "auto",\\
  "--text-comment-box--marginBottom": "0",\\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\\
\\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\\
\\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_greyscale--intensity": 100,\\
\\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_lighten--intensity": 80,\\
\\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_darken--intensity": 80,\\
\\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_overlay--intensity": 80,\\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\\
\\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_colorize--intensity": 80,\\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\\
\\
\\
  "--button-normal--primaryColor": "var(--palette-color7)",\\
  "--button-normal--borderColor": "var(--palette-color7)",\\
  "--button-normal--shadowColor": "var(--greyscale3)",\\
  "--text-button-normal--color": "var(--palette-color0)",\\
  "--text-button-normal--fontFamily": "var(--font2)",\\
  "--text-button-normal--fontType": "regular",\\
  "--text-button-normal--fontSize--desktop": "16px",\\
  "--text-button-normal--fontSize--tablet": "16px",\\
  "--text-button-normal--fontSize--mobile": "16px",\\
\\
  "--button-selected--primaryColor": "var(--palette-color5)",\\
  "--button-selected--borderColor": "var(--palette-color5)",\\
  "--button-selected--shadowColor": "var(--greyscale3)",\\
  "--text-button-selected--color": "var(--palette-color0)",\\
  "--text-button-selected--fontFamily": "var(--font2)",\\
  "--text-button-selected--fontType": "regular",\\
  "--text-button-selected--fontSize--desktop": "16px",\\
  "--text-button-selected--fontSize--tablet": "16px",\\
  "--text-button-selected--fontSize--mobile": "16px",\\
\\
  "--button-disabled--primaryColor": "var(--palette-color3)",\\
  "--button-disabled--borderColor": "var(--palette-color3)",\\
  "--button-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-button-disabled--color": "var(--palette-color4)",\\
  "--text-button-disabled--fontFamily": "var(--font2)",\\
  "--text-button-disabled--fontType": "regular",\\
  "--text-button-disabled--fontSize--desktop": "16px",\\
  "--text-button-disabled--fontSize--tablet": "16px",\\
  "--text-button-disabled--fontSize--mobile": "16px",\\
\\
  "--button-hover--primaryColor": "#112FA7",\\
  "--button-hover--borderColor": "#112FA7",\\
  "--button-hover--shadowColor": "var(--greyscale3)",\\
  "--text-button-hover--color": "var(--palette-color0)",\\
  "--text-button-hover--fontFamily": "var(--font2)",\\
  "--text-button-hover--fontType": "regular",\\
  "--text-button-hover--fontSize--desktop": "16px",\\
  "--text-button-hover--fontSize--tablet": "16px",\\
  "--text-button-hover--fontSize--mobile": "16px",\\
\\
  "--button-visited--primaryColor": "#112FA780",\\
  "--button-visited--borderColor": "#112FA780",\\
  "--button-visited--shadowColor": "var(--greyscale3)",\\
  "--text-button-visited--color": "var(--palette-color0)",\\
  "--text-button-visited--fontFamily": "var(--font2)",\\
  "--text-button-visited--fontType": "regular",\\
  "--text-button-visited--fontSize--desktop": "16px",\\
  "--text-button-visited--fontSize--tablet": "16px",\\
  "--text-button-visited--fontSize--mobile": "16px",\\
\\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-normal--color": "var(--palette-color4)",\\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\\
  "--text-checkbox-normal--fontType": "regular",\\
  "--text-checkbox-normal--fontSize--desktop": "22px",\\
  "--text-checkbox-normal--fontSize--tablet": "20px",\\
  "--text-checkbox-normal--fontSize--mobile": "20px",\\
\\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-selected--color": "var(--palette-color4)",\\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\\
  "--text-checkbox-selected--fontType": "regular",\\
  "--text-checkbox-selected--fontSize--desktop": "22px",\\
  "--text-checkbox-selected--fontSize--tablet": "20px",\\
  "--text-checkbox-selected--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-checked--fontType": "regular",\\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-hover--color": "var(--palette-color5)",\\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\\
  "--text-checkbox-hover--fontType": "regular",\\
  "--text-checkbox-hover--fontSize--desktop": "22px",\\
  "--text-checkbox-hover--fontSize--tablet": "20px",\\
  "--text-checkbox-hover--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \\
  "--inputfield-normal--borderColor": "var(--palette-color3)",\\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-normal--color": "var(--palette-color4)",\\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\\
  "--text-inputfield-normal--fontType": "regular",\\
  "--text-inputfield-normal--fontSize--desktop": "18px",\\
  "--text-inputfield-normal--fontSize--tablet": "20px",\\
  "--text-inputfield-normal--fontSize--mobile": "20px",\\
\\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\\
  "--inputfield-active--borderColor": "var(--palette-color7)",\\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\\
  "--text-inputfield-active--color": "var(--palette-color4)",\\
  "--text-inputfield-active--fontFamily": "var(--font1)",\\
  "--text-inputfield-active--fontType": "regular",\\
  "--text-inputfield-active--fontSize--desktop": "18px",\\
  "--text-inputfield-active--fontSize--tablet": "20px",\\
  "--text-inputfield-active--fontSize--mobile": "20px",\\
\\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\\
  "--text-inputfield-disabled--fontType": "regular",\\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\\
\\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\\
  "--text-inputfield-focusLost--fontType": "regular",\\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\\
\\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\\
  "--inputfield-error--borderColor": "var(--error)",\\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-error--color": "var(--palette-color4)",\\
  "--text-inputfield-error--fontFamily": "var(--font1)",\\
  "--text-inputfield-error--fontType": "regular",\\
  "--text-inputfield-error--fontSize--desktop": "18px",\\
  "--text-inputfield-error--fontSize--tablet": "20px",\\
  "--text-inputfield-error--fontSize--mobile": "20px",\\
\\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-normal--color": "var(--palette-color4)",\\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\\
  "--text-dropdown-normal--fontType": "italic",\\
  "--text-dropdown-normal--fontSize--desktop": "18px",\\
  "--text-dropdown-normal--fontSize--tablet": "18px",\\
  "--text-dropdown-normal--fontSize--mobile": "18px",\\
\\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-selected--color": "var(--palette-color4)",\\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\\
  "--text-dropdown-selected--fontType": "italic",\\
  "--text-dropdown-selected--fontSize--desktop": "18px",\\
  "--text-dropdown-selected--fontSize--tablet": "18px",\\
  "--text-dropdown-selected--fontSize--mobile": "18px",\\
\\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\\
  "--text-dropdown-disabled--fontType": "italic",\\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\\
\\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-hover--color": "var(--palette-color4)",\\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\\
  "--text-dropdown-hover--fontType": "italic",\\
  "--text-dropdown-hover--fontSize--desktop": "18px",\\
  "--text-dropdown-hover--fontSize--tablet": "18px",\\
  "--text-dropdown-hover--fontSize--mobile": "18px",\\
\\
  "--radio-normal--primaryColor": "var(--palette-color0)",\\
  "--radio-normal--borderColor": "var(--palette-color3)",\\
  "--radio-normal--shadowColor": "var(--greyscale3)",\\
  "--text-radio-normal--color": "var(--palette-color4)",\\
  "--text-radio-normal--fontFamily": "var(--font1)",\\
  "--text-radio-normal--fontType": "regular",\\
  "--text-radio-normal--fontSize--desktop": "22px",\\
  "--text-radio-normal--fontSize--tablet": "20px",\\
  "--text-radio-normal--fontSize--mobile": "20px",\\
\\
  "--radio-selected--primaryColor": "var(--palette-color0)",\\
  "--radio-selected--borderColor": "var(--palette-color4)",\\
  "--radio-selected--shadowColor": "var(--greyscale3)",\\
  "--text-radio-selected--color": "var(--palette-color4)",\\
  "--text-radio-selected--fontFamily": "var(--font1)",\\
  "--text-radio-selected--fontType": "regular",\\
  "--text-radio-selected--fontSize--desktop": "22px",\\
  "--text-radio-selected--fontSize--tablet": "20px",\\
  "--text-radio-selected--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-checked--fontType": "regular",\\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--radio-hover--primaryColor": "var(--palette-color0)",\\
  "--radio-hover--borderColor": "var(--palette-color3)",\\
  "--radio-hover--shadowColor": "var(--greyscale3)",\\
  "--text-radio-hover--color": "var(--palette-color5)",\\
  "--text-radio-hover--fontFamily": "var(--font1)",\\
  "--text-radio-hover--fontType": "regular",\\
  "--text-radio-hover--fontSize--desktop": "22px",\\
  "--text-radio-hover--fontSize--tablet": "20px",\\
  "--text-radio-hover--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-unchecked--fontType": "regular",\\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--video_preset-color": "#666666",\\
  "--video_preset-borderColor": "#666666",\\
  \\
  "--clickbox-preset-fill-color": "#3F80E4",\\
\\
  "--drag-object-default-state-fill-color": "255, 255, 255",\\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drag-object-default-state-border-color": "214, 213, 209",\\
  "--drag-object-hover-state-border-color": "214, 213, 209",\\
  "--drag-object-transition-state-border-color": "214, 213, 209",\\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\\
\\
  "--drop-object-default-state-fill-color": "255, 255, 255",\\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drop-object-default-state-border-color": "42, 49, 62",\\
  "--drop-object-hover-state-border-color": "230, 132, 80",\\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\\
}',
uic_presets:'{\\
  "cp_button_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 1,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "--button-selected--shadowColor",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-visited--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style": {\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "#707070",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_hover": {\\
    "fill": "#9ec4f3",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--black)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_selected": {\\
    "fill": "var(--palette-color5)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_visited": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_disabled": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_active": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-active--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-active--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-active--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_focusLost": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-focusLost--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-focusLost--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-focusLost--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_error": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-error--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-error--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-error--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 14,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.78\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "video_preset_style": {\\
    "fillEnable": 0,\\
    "strokeEnable": 0,\\
    "shadowEnable": 0,\\
    "fill": "var(--video_preset-color)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--video_preset-border)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_comment_box_shape_1_solid_style": {\\
    "fill": "#F2B807",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clickbox_shape_solid_style": {\\
    "fill": "var(--clickbox-preset-fill-color)",\\
    "fillOpacity": 0.6,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "2, 3",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#333333",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#000000",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#D6D5D1",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clicktoreveal_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#ffffff",\\
    "fillOpacity": 1,\\
    "stroke": "#ffffff",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 3,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color7)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color8)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_blue": {\\
    "fill": "#ADD8E6",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
slideAudios:'StAd25,StAd27,StAd29',
vestr:0,
vim:0,
slides:'Slide3417,Slide390,Slide507,Slide622,Slide739,Slide856,Slide973,Slide1010,Slide1047,Slide1164,Slide1201,Slide1316,Slide1433,Slide1548,Slide1665,Slide1783,Slide1900,Slide2017,Slide2132,Slide2249,Slide2366,Slide2403,Slide2447,Slide2564,Slide2681,Slide2798,Slide2915',
slideVideos:['si2440'],
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Blank 1","type":"slide","parentId":null,"id":"Slide3417","isVisible":true,"slideVisited":false,"originalId":3417,"labelShouldBeInSync":true},{"label":"Simulation slide 1","type":"slide","parentId":null,"id":"Slide390","isVisible":true,"slideVisited":false,"originalId":390,"labelShouldBeInSync":true},{"label":"Simulation slide 2","type":"slide","parentId":null,"id":"Slide507","isVisible":true,"slideVisited":false,"originalId":507,"labelShouldBeInSync":true},{"label":"Simulation slide 3","type":"slide","parentId":null,"id":"Slide622","isVisible":true,"slideVisited":false,"originalId":622,"labelShouldBeInSync":true},{"label":"Simulation slide 4","type":"slide","parentId":null,"id":"Slide739","isVisible":true,"slideVisited":false,"originalId":739,"labelShouldBeInSync":true},{"label":"Simulation slide 5","type":"slide","parentId":null,"id":"Slide856","isVisible":true,"slideVisited":false,"originalId":856,"labelShouldBeInSync":true},{"label":"Simulation slide 6","type":"slide","parentId":null,"id":"Slide973","isVisible":true,"slideVisited":false,"originalId":973,"labelShouldBeInSync":true},{"label":"Simulation slide 7","type":"slide","parentId":null,"id":"Slide1010","isVisible":true,"slideVisited":false,"originalId":1010,"labelShouldBeInSync":true},{"label":"Simulation slide 8","type":"slide","parentId":null,"id":"Slide1047","isVisible":true,"slideVisited":false,"originalId":1047,"labelShouldBeInSync":true},{"label":"Simulation slide 9","type":"slide","parentId":null,"id":"Slide1164","isVisible":true,"slideVisited":false,"originalId":1164,"labelShouldBeInSync":true},{"label":"Simulation slide 10","type":"slide","parentId":null,"id":"Slide1201","isVisible":true,"slideVisited":false,"originalId":1201,"labelShouldBeInSync":true},{"label":"Simulation slide 11","type":"slide","parentId":null,"id":"Slide1316","isVisible":true,"slideVisited":false,"originalId":1316,"labelShouldBeInSync":true},{"label":"Simulation slide 12","type":"slide","parentId":null,"id":"Slide1433","isVisible":true,"slideVisited":false,"originalId":1433,"labelShouldBeInSync":true},{"label":"Simulation slide 13","type":"slide","parentId":null,"id":"Slide1548","isVisible":true,"slideVisited":false,"originalId":1548,"labelShouldBeInSync":true},{"label":"Simulation slide 14","type":"slide","parentId":null,"id":"Slide1665","isVisible":true,"slideVisited":false,"originalId":1665,"labelShouldBeInSync":true},{"label":"Simulation slide 17","type":"slide","parentId":null,"id":"Slide1783","isVisible":true,"slideVisited":false,"originalId":1783,"labelShouldBeInSync":true},{"label":"Simulation slide 18","type":"slide","parentId":null,"id":"Slide1900","isVisible":true,"slideVisited":false,"originalId":1900,"labelShouldBeInSync":true},{"label":"Simulation slide 19","type":"slide","parentId":null,"id":"Slide2017","isVisible":true,"slideVisited":false,"originalId":2017,"labelShouldBeInSync":true},{"label":"Simulation slide 20","type":"slide","parentId":null,"id":"Slide2132","isVisible":true,"slideVisited":false,"originalId":2132,"labelShouldBeInSync":true},{"label":"Simulation slide 21","type":"slide","parentId":null,"id":"Slide2249","isVisible":true,"slideVisited":false,"originalId":2249,"labelShouldBeInSync":true},{"label":"Simulation slide 22","type":"slide","parentId":null,"id":"Slide2366","isVisible":true,"slideVisited":false,"originalId":2366,"labelShouldBeInSync":true},{"label":"Simulation slide 23","type":"slide","parentId":null,"id":"Slide2403","isVisible":true,"slideVisited":false,"originalId":2403,"labelShouldBeInSync":true},{"label":"Simulation slide 24","type":"slide","parentId":null,"id":"Slide2447","isVisible":true,"slideVisited":false,"originalId":2447,"labelShouldBeInSync":true},{"label":"Simulation slide 25","type":"slide","parentId":null,"id":"Slide2564","isVisible":true,"slideVisited":false,"originalId":2564,"labelShouldBeInSync":true},{"label":"Simulation slide 26","type":"slide","parentId":null,"id":"Slide2681","isVisible":true,"slideVisited":false,"originalId":2681,"labelShouldBeInSync":true},{"label":"Simulation slide 27","type":"slide","parentId":null,"id":"Slide2798","isVisible":true,"slideVisited":false,"originalId":2798,"labelShouldBeInSync":true},{"label":"Simulation slide 28","type":"slide","parentId":null,"id":"Slide2915","isVisible":true,"slideVisited":false,"originalId":2915,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":false,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:3417,
text:[]
}
,{
link:390,
text:['""','""']
}
,{
link:507,
text:['""','""']
}
,{
link:622,
text:['""','""']
}
,{
link:739,
text:['""','""']
}
,{
link:856,
text:['""','""']
}
,{
link:973,
text:['""']
}
,{
link:1010,
text:['""']
}
,{
link:1047,
text:['""','""']
}
,{
link:1164,
text:['""']
}
,{
link:1201,
text:['""','""']
}
,{
link:1316,
text:['""','""']
}
,{
link:1433,
text:['""','""']
}
,{
link:1548,
text:['""','""']
}
,{
link:1665,
text:['""']
}
,{
link:1783,
text:['""','""']
}
,{
link:1900,
text:['""','""']
}
,{
link:2017,
text:['""','""']
}
,{
link:2132,
text:['""','""']
}
,{
link:2249,
text:['""','""']
}
,{
link:2366,
text:['""']
}
,{
link:2403,
text:['""']
}
,{
link:2447,
text:['""','""']
}
,{
link:2564,
text:['""','""']
}
,{
link:2681,
text:['""','""']
}
,{
link:2798,
text:['""']
}
,{
link:2915,
text:['""']
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/01007.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01044.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01081.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01198.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01235.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01350.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01467.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01582.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01699.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01817.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01934.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02051.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02166.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02283.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02400.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02436.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02481.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02598.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02715.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02832.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02949.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03604.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03655.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0424.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0541.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0656.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0773.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0890.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
'vr/Vi2429.mp4'
];
cp.model.tocVideos=[
];
cp.model.audios=[
'ar/StAd24.mp3',
'ar/StAd26.mp3',
'ar/StAd28.mp3'
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',27,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
cp.cv('variableEditBoxNum_1','',0,15,0);
cp.cv('variableEditBoxNum_2','',0,15,0);
cp.cv('variableEditBoxNum_3','',0,15,0);
cp.cv('variableEditBoxNum_4','',0,15,0);
cp.cv('variableEditBoxStr_1','',0,15,0);
cp.cv('variableEditBoxStr_2','',0,15,0);
cp.cv('variableEditBoxStr_3','',0,15,0);
cp.cv('variableEditBoxStr_4','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,variableEditBoxNum_1,variableEditBoxNum_2,variableEditBoxNum_3,variableEditBoxNum_4,variableEditBoxStr_1,variableEditBoxStr_2,variableEditBoxStr_3,variableEditBoxStr_4,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
